import express from "express";
import http from "http";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, Modality, LiveServerMessage } from "@google/genai";
import { WebSocketServer, WebSocket } from "ws";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Allow base64 canvas drawings up to 25MB
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Initialize Google GenAI
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is not set in environment variables.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Resilient model calling helper with fallback
const CANDIDATE_MODELS = [
  "gemini-3.7-flash",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3.6-flash",
  "gemini-2.0-flash",
];

async function callGenerateContentWithFallback(
  ai: GoogleGenAI,
  params: {
    contents: any;
    config?: any;
  }
) {
  let lastError: any = null;

  for (const model of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: params.config,
      });
      return { response, modelUsed: model };
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || String(err);
      console.warn(`[Gemini API] Call on model ${model} encountered issue (${err?.status || "error"}), trying next model: ${errMsg.slice(0, 140)}`);
      // Immediately cascade to next candidate model in list
    }
  }

  // Second pass with brief backoff if initial pass was throttled
  await new Promise((r) => setTimeout(r, 600));
  for (const model of [CANDIDATE_MODELS[0], CANDIDATE_MODELS[1]]) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: params.config,
      });
      return { response, modelUsed: model };
    } catch (retryErr: any) {
      lastError = retryErr;
    }
  }

  throw lastError || new Error("All Gemini candidate models failed. Please try again.");
}

function cleanJsonText(raw: string): string {
  if (!raw) return "{}";
  let cleaned = raw.trim();
  if (cleaned.startsWith("```json")) {
    cleaned = cleaned.replace(/^```json\s*/, "").replace(/\s*```$/, "");
  } else if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```\s*/, "").replace(/\s*```$/, "");
  }
  return cleaned.trim();
}

/**
 * Resilient JSON parser that repairs unescaped LaTeX backslashes, bad Unicode escapes (\u...),
 * and extracts valid JSON objects/arrays from LLM outputs.
 */
function safeParseJson<T = any>(raw: string, fallback: T): T {
  if (!raw || typeof raw !== "string") return fallback;

  let text = cleanJsonText(raw);

  // 1. Direct standard parse
  try {
    return JSON.parse(text);
  } catch (e1) {
    // Continue with repair attempts
  }

  // 2. Extract outermost JSON structure if wrapped in other text
  const firstBrace = text.indexOf("{");
  const lastBrace = text.lastIndexOf("}");
  const firstBracket = text.indexOf("[");
  const lastBracket = text.lastIndexOf("]");

  if (firstBrace !== -1 && lastBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
    text = text.substring(firstBrace, lastBrace + 1);
  } else if (firstBracket !== -1 && lastBracket !== -1) {
    text = text.substring(firstBracket, lastBracket + 1);
  }

  try {
    return JSON.parse(text);
  } catch (e2) {
    // Continue with repair attempts
  }

  // 3. Regex-based escape fixing (invalid unicode \u... or invalid single backslashes in LaTeX)
  try {
    // Fix invalid unicode escapes (\u followed by anything other than 4 hex characters)
    let fixed = text.replace(/\\u(?![0-9a-fA-F]{4})/gi, "\\\\u");
    // Fix single backslashes that are not standard JSON escape codes (" \ / b f n r t u)
    fixed = fixed.replace(/\\([^"\\\/bfnrtu])/g, "\\\\$1");
    return JSON.parse(fixed);
  } catch (e3) {
    // Continue
  }

  // 4. Character-by-character scan and escape repair inside string literals
  try {
    let inString = false;
    let isEscaped = false;
    let result = "";
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (char === '"' && !isEscaped) {
        inString = !inString;
        result += char;
      } else if (inString && char === "\\") {
        const next = text[i + 1];
        if (
          next === '"' ||
          next === "\\" ||
          next === "/" ||
          next === "b" ||
          next === "f" ||
          next === "n" ||
          next === "r" ||
          next === "t"
        ) {
          result += char;
        } else if (next === "u" && /^[0-9a-fA-F]{4}$/.test(text.substring(i + 2, i + 6))) {
          result += char;
        } else {
          result += "\\\\";
        }
      } else {
        result += char;
      }
      isEscaped = char === "\\" && !isEscaped;
    }
    return JSON.parse(result);
  } catch (e4) {
    console.warn("[safeParseJson] Could not parse JSON response:", e4);
  }

  return fallback;
}

// Health endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    models: CANDIDATE_MODELS,
  });
});

// Generate practice questions for a topic
app.post("/api/generate-questions", async (req, res) => {
  try {
    const { topic } = req.body;
    if (!topic || typeof topic !== "string") {
      res.status(400).json({ error: "Please provide a valid topic string." });
      return;
    }

    const ai = getGeminiClient();
    const prompt = `Generate exactly 4 concise, high-yield practice questions or problems that a student can easily hand-write an answer/solution for on a chalkboard slate pad, for the topic: "${topic}".
Include varying difficulty (introductory, practical, conceptual/challenging).
Make the questions clear, standalone, and inspiring.`;

    const { response } = await callGenerateContentWithFallback(ai, {
      contents: prompt,
      config: {
        systemInstruction: "You are an expert tutor designing interactive chalkboard practice drills for students.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            questions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Array of 4 short chalkboard practice questions.",
            },
          },
          required: ["questions"],
        },
      },
    });

    const parsed = safeParseJson<{ questions?: string[] }>(response.text || "{}", { questions: [] });
    res.json({
      questions: parsed.questions || [],
    });
  } catch (error: any) {
    console.error("Error generating questions:", error);
    res.status(500).json({
      error: error.message || "Failed to generate questions. Please ensure GEMINI_API_KEY is configured.",
    });
  }
});

// Check work on the slate canvas
app.post("/api/check-work", async (req, res) => {
  try {
    const { imageBase64, topic, question } = req.body;
    if (!imageBase64 || typeof imageBase64 !== "string") {
      res.status(400).json({ error: "Missing canvas image data." });
      return;
    }

    // Clean data URL prefix if sent
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");

    const ai = getGeminiClient();

    const contextDesc = [
      topic ? `Topic: "${topic}"` : "Topic: General practice / homework",
      question ? `Assigned Question: "${question}"` : "Question: Open practice",
    ].join("\n");

    const promptText = `You are a master, encouraging chalkboard tutor reviewing a student's handwritten work on the slate chalkboard.
${contextDesc}

Carefully inspect the attached image of the student's handwritten chalkboard strokes.
1. Transcribe what the student wrote or drew as accurately as possible.
2. Check for any factual errors, math calculation mistakes, spelling/grammatical issues, formula slips, or conceptual flaws.
3. Grade the work objectively with an overall score from 0 to 100 based on correctness and effort.
4. Highlight specific mistake snippets with clear explanations and the exact correct solution.
5. Provide a warm, genuine praise sentence highlighting what they got right or did well.
6. Provide 1-2 actionable tips for improvement.

IMPORTANT: Do not output unescaped backslashes in your JSON strings. Write standard math symbols, plain text, or double-escaped notation.

Return clean JSON matching the schema.`;

    const { response } = await callGenerateContentWithFallback(ai, {
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/png",
              data: cleanBase64,
            },
          },
          {
            text: promptText,
          },
        ],
      },
      config: {
        systemInstruction: "You are an encouraging, sharp, and helpful tutor evaluating handwriting on a blackboard.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overall_score: {
              type: Type.INTEGER,
              description: "Overall grade score between 0 and 100.",
            },
            transcribed_text: {
              type: Type.STRING,
              description: "Transcription of what was handwritten on the slate.",
            },
            praise: {
              type: Type.STRING,
              description: "Warm, encouraging sentence highlighting good reasoning or effort.",
            },
            mistakes: {
              type: Type.ARRAY,
              description: "List of identified errors. Empty if flawless.",
              items: {
                type: Type.OBJECT,
                properties: {
                  text_snippet: {
                    type: Type.STRING,
                    description: "The specific faulty word, step, term, or formula.",
                  },
                  issue: {
                    type: Type.STRING,
                    description: "Brief summary of what is incorrect.",
                  },
                  correction: {
                    type: Type.STRING,
                    description: "The correct solution or replacement.",
                  },
                  explanation: {
                    type: Type.STRING,
                    description: "Helpful 1-sentence explanation of why and how to fix it.",
                  },
                },
                required: ["text_snippet", "issue", "correction"],
              },
            },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "1-2 brief practical study tips.",
            },
          },
          required: ["overall_score", "praise", "mistakes"],
        },
      },
    });

    const parsed = safeParseJson<{
      overall_score?: number;
      transcribed_text?: string;
      praise?: string;
      mistakes?: any[];
      tips?: string[];
    }>(response.text || "{}", {
      overall_score: 80,
      transcribed_text: "",
      praise: "Good work on your handwriting attempt!",
      mistakes: [],
      tips: [],
    });

    res.json({
      overall_score: Math.min(100, Math.max(0, parsed.overall_score ?? 85)),
      transcribed_text: parsed.transcribed_text || "",
      praise: parsed.praise || "Great attempt on the chalkboard!",
      mistakes: parsed.mistakes || [],
      tips: parsed.tips || [],
      topic,
      question,
    });
  } catch (error: any) {
    console.error("Error checking work:", error);
    res.status(500).json({
      error: error.message || "Failed to analyze handwritten work. Please ensure GEMINI_API_KEY is configured.",
    });
  }
});

// Follow-up Q&A with the chalkboard tutor
app.post("/api/ask-tutor", async (req, res) => {
  try {
    const { question, context } = req.body;
    if (!question || typeof question !== "string") {
      res.status(400).json({ error: "Missing student question." });
      return;
    }

    const ai = getGeminiClient();

    let contextSummary = "";
    if (context) {
      contextSummary = `
Context:
- Practice Topic: ${context.topic || "N/A"}
- Question on board: ${context.question || "N/A"}
- Score received: ${context.score ?? "N/A"}/100
- Mistakes identified: ${JSON.stringify(context.mistakes || [])}
- Transcribed writing: ${context.transcribed_text || "N/A"}
`;
    }

    const prompt = `You are a supportive, insightful chalkboard tutor answering a student's follow-up question.
${contextSummary}

Student asks: "${question}"

Provide a friendly, concise, and crystal-clear explanation in 2-3 short paragraphs. Break down steps or formulas simply using plain text and bullet points if helpful.`;

    const { response } = await callGenerateContentWithFallback(ai, {
      contents: prompt,
      config: {
        systemInstruction: "You are a warm, direct, step-by-step academic tutor.",
      },
    });

    res.json({
      answer: response.text || "I'm here to help! Could you clarify your question?",
    });
  } catch (error: any) {
    console.error("Error asking tutor:", error);
    res.status(500).json({
      error: error.message || "Failed to answer question.",
    });
  }
});

// Transform student's chalkboard drawing into a rich AI-generated visual image
app.post("/api/generate-drawing-image", async (req, res) => {
  try {
    const { imageBase64, style = "illustration", topic, question, customPrompt } = req.body;
    if (!imageBase64 || typeof imageBase64 !== "string") {
      res.status(400).json({ error: "Missing drawing image data." });
      return;
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");
    const ai = getGeminiClient();

    const styleDescriptions: Record<string, string> = {
      realistic: "photorealistic, hyper-detailed, lifelike real world photograph, natural daylight, crisp focus, 8k resolution",
      illustration: "vibrant modern digital concept art illustration, clean lines, rich palette, expressive and polished",
      watercolor: "traditional ethereal watercolor and ink painting, soft blended washes, textured paper, artistic brushstrokes",
      "3d-render": "cinematic 3D render, Pixar/Unreal Engine aesthetic, soft ambient occlusion, volumetric lighting, rich tactile materials",
      anime: "masterpiece anime artwork, Makoto Shinkai/Studio Ghibli aesthetic, luminous atmosphere, detailed scenery",
      "chalk-masterpiece": "spectacular, richly colored pastel chalk art mural, vivid dust glow, dramatic contrast on dark textured slate",
    };

    const chosenStyleDesc = styleDescriptions[style] || styleDescriptions.illustration;

    const analysisPrompt = `You are an expert art director, visionary illustrator, and STEM educator reviewing a student's chalkboard drawing / sketch.
Context topic: ${topic || "General Drawing"}
Context question: ${question || "Open Chalkboard Practice"}
${customPrompt ? `User refinement wish: "${customPrompt}"` : ""}

Carefully inspect the attached chalkboard image of the student's handwritten drawing, sketch, graph, or diagram:
1. Identify the core subject or concept drawn (e.g. "A blooming sunflower with bees", "An orbital model of an atom with electrons", "A cozy wooden cabin in the snowy woods", "A sailing boat in the ocean at sunset", "A quadratic parabola graph with vertex", "A human heart with blood flow ventricles", "A smiling cartoon cat").
2. Write a 2-3 sentence descriptive summary of the drawing composition, elements, and layout.
3. Craft an exceptional, descriptive text-to-image prompt that transforms this student sketch into a stunning visual artwork in this style: "${chosenStyleDesc}". Include vivid details of composition, lighting, textures, colors, and perspective based on what the student drew.
4. Categorize it into a category (e.g. "Science & Nature", "Math & Geometry", "Animals", "Space & Astronomy", "Architecture", "Character & Story", "Technology", "Art & Design").
5. Provide a short 1-2 sentence fascinating educational fact or insight related to the subject drawn.

Return clean JSON matching the schema.`;

    const { response: analysisResponse } = await callGenerateContentWithFallback(ai, {
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/png",
              data: cleanBase64,
            },
          },
          {
            text: analysisPrompt,
          },
        ],
      },
      config: {
        systemInstruction: "You are an imaginative, perceptive art director and STEM educator.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: {
              type: Type.STRING,
              description: "Concise title of the subject drawn by the student.",
            },
            detailedDescription: {
              type: Type.STRING,
              description: "2-3 sentences describing the drawing layout and elements.",
            },
            imagePrompt: {
              type: Type.STRING,
              description: "Rich descriptive prompt for the image generation model.",
            },
            category: {
              type: Type.STRING,
              description: "Category of the drawn subject.",
            },
            educationalFact: {
              type: Type.STRING,
              description: "1-2 sentence interesting educational fact about the subject.",
            },
          },
          required: ["subject", "detailedDescription", "imagePrompt", "category", "educationalFact"],
        },
      },
    });

    const parsedAnalysis = safeParseJson<{
      subject?: string;
      detailedDescription?: string;
      imagePrompt?: string;
      category?: string;
      educationalFact?: string;
    }>(analysisResponse.text || "{}", {
      subject: "Student Chalkboard Drawing",
      detailedDescription: "A creative sketch drawn on the chalkboard slate.",
      imagePrompt: `A beautiful artwork of the drawing in ${chosenStyleDesc}`,
      category: "Creative Arts",
      educationalFact: "Visual sketches help reinforce concept retention and spatial reasoning!",
    });

    const subject = parsedAnalysis.subject || "Student Drawing";
    const detailedDescription = parsedAnalysis.detailedDescription || "Hand-drawn chalkboard illustration.";
    const imagePrompt = parsedAnalysis.imagePrompt || `${subject}, ${chosenStyleDesc}`;
    const category = parsedAnalysis.category || "General";
    const educationalFact = parsedAnalysis.educationalFact || "Drawing concepts strengthens understanding!";

    // Multi-tier resilient image generation pipeline
    let generatedImageUrl = "";
    let generationSource = "";

    const imageModels = [
      "gemini-3.1-flash-lite-image",
      "gemini-3.1-flash-image",
    ];

    // Tier 1: Attempt Gemini Multimodal Image Generation
    for (const imgModel of imageModels) {
      try {
        const imgResponse = await ai.models.generateContent({
          model: imgModel,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: "image/png",
                  data: cleanBase64,
                },
              },
              {
                text: `Create a vivid, high quality, complete visual image depicting: ${imagePrompt}. Style: ${chosenStyleDesc}. Transform the chalk sketch into a rich visual scene while preserving the core subject and composition.`,
              },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1",
            },
          },
        });

        if (imgResponse.candidates && imgResponse.candidates[0]?.content?.parts) {
          for (const part of imgResponse.candidates[0].content.parts) {
            if (part.inlineData && part.inlineData.data) {
              const mime = part.inlineData.mimeType || "image/png";
              generatedImageUrl = `data:${mime};base64,${part.inlineData.data}`;
              generationSource = `gemini-vision-${imgModel}`;
              break;
            }
          }
        }

        if (generatedImageUrl) break;
      } catch (imgErr: any) {
        console.warn(`[Image Gen] Gemini sketch-to-image on ${imgModel} unavailable or quota exceeded:`, imgErr?.status || imgErr?.message || imgErr);
      }
    }

    // Tier 1.5: Text-to-image with Gemini
    if (!generatedImageUrl) {
      for (const imgModel of imageModels) {
        try {
          const imgResponse = await ai.models.generateContent({
            model: imgModel,
            contents: {
              parts: [
                {
                  text: `${imagePrompt}, ${chosenStyleDesc}, masterpiece, vivid lighting, detailed, centered composition, high quality`,
                },
              ],
            },
            config: {
              imageConfig: {
                aspectRatio: "1:1",
              },
            },
          });

          if (imgResponse.candidates && imgResponse.candidates[0]?.content?.parts) {
            for (const part of imgResponse.candidates[0].content.parts) {
              if (part.inlineData && part.inlineData.data) {
                const mime = part.inlineData.mimeType || "image/png";
                generatedImageUrl = `data:${mime};base64,${part.inlineData.data}`;
                generationSource = `gemini-text-${imgModel}`;
                break;
              }
            }
          }

          if (generatedImageUrl) break;
        } catch (textImgErr: any) {
          console.warn(`[Image Gen] Gemini text-to-image on ${imgModel} unavailable:`, textImgErr?.status || textImgErr?.message || textImgErr);
        }
      }
    }

    // Tier 2: Try Imagen 3 (imagen-3.0-generate-002)
    if (!generatedImageUrl) {
      try {
        const imagenResponse = await (ai.models as any).generateImages({
          model: "imagen-3.0-generate-002",
          prompt: `${imagePrompt}, ${chosenStyleDesc}, masterpiece, 8k resolution, photorealistic details, high artistic quality`,
          config: {
            numberOfImages: 1,
            aspectRatio: "1:1",
            outputMimeType: "image/jpeg",
          },
        });

        if (imagenResponse?.generatedImages?.[0]?.image?.imageBytes) {
          const rawBytes = imagenResponse.generatedImages[0].image.imageBytes;
          generatedImageUrl = `data:image/jpeg;base64,${rawBytes}`;
          generationSource = "imagen-3.0";
        }
      } catch (imagenErr: any) {
        console.warn("[Image Gen] Imagen 3 unavailable or quota exceeded:", imagenErr?.status || imagenErr?.message || imagenErr);
      }
    }

    // Tier 3: High-Res Generative Neural Rendering Fallback (Fetches and embeds as direct base64)
    if (!generatedImageUrl) {
      try {
        const safePrompt = encodeURIComponent(`${subject}, ${imagePrompt}, ${chosenStyleDesc}`.slice(0, 400));
        const seed = Math.floor(Math.random() * 1000000);
        const pollUrl = `https://image.pollinations.ai/prompt/${safePrompt}?width=1024&height=1024&nologo=true&seed=${seed}`;
        
        const fetchController = new AbortController();
        const timeoutId = setTimeout(() => fetchController.abort(), 9000);
        
        const pollRes = await fetch(pollUrl, { signal: fetchController.signal });
        clearTimeout(timeoutId);
        
        if (pollRes.ok) {
          const arrayBuffer = await pollRes.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          const base64Data = buffer.toString("base64");
          const mime = pollRes.headers.get("content-type") || "image/jpeg";
          generatedImageUrl = `data:${mime};base64,${base64Data}`;
          generationSource = "neural-renderer";
        }
      } catch (fallbackErr: any) {
        console.warn("[Image Gen] Generative neural fallback fetch timed out or failed:", fallbackErr?.message || fallbackErr);
      }
    }

    // Tier 4: SVG Vector Masterpiece Generation via Gemini Text/Code (100% quota resilient)
    if (!generatedImageUrl) {
      try {
        const svgPrompt = `Create a visually stunning, detailed, complete modern SVG illustration representing this student drawing:
Subject: "${subject}"
Description: "${detailedDescription}"
Style: "${chosenStyleDesc}"

Rules:
1. Output ONLY a valid <svg viewBox="0 0 800 800" xmlns="http://www.w3.org/2000/svg">...</svg> tag without markdown or code fences.
2. Include rich gradient fills (<defs><linearGradient>...), layered geometric shapes, glowing accents, and detailed vector paths.
3. Make it colorful, polished, and fitting the style.`;

        const { response: svgResponse } = await callGenerateContentWithFallback(ai, {
          contents: [{ parts: [{ text: svgPrompt }] }],
          config: {
            systemInstruction: "You are an expert SVG vector artist. Output raw SVG code only.",
          },
        });

        let svgText = (svgResponse.text || "").trim();
        svgText = svgText.replace(/^```svg\n?/, "").replace(/^```xml\n?/, "").replace(/^```\n?/, "").replace(/\n?```$/, "").trim();
        if (svgText.includes("<svg") && svgText.includes("</svg>")) {
          const startIdx = svgText.indexOf("<svg");
          const endIdx = svgText.lastIndexOf("</svg>") + 6;
          const cleanSvg = svgText.substring(startIdx, endIdx);
          const svgBase64 = Buffer.from(cleanSvg, "utf-8").toString("base64");
          generatedImageUrl = `data:image/svg+xml;base64,${svgBase64}`;
          generationSource = "gemini-svg-vector";
        }
      } catch (svgErr: any) {
        console.warn("[Image Gen] SVG generation fallback error:", svgErr);
      }
    }

    res.json({
      imageUrl: generatedImageUrl || "",
      generationSource,
      subject,
      detailedDescription,
      imagePrompt,
      category,
      educationalFact,
      style,
    });
  } catch (error: any) {
    console.error("Error generating drawing image:", error);
    res.status(500).json({
      error: error.message || "Failed to generate visual image from drawing.",
    });
  }
});

// AI Auto-Draw on Slate: Generate chalk strokes, curves, and annotations from student command/order
app.post("/api/auto-draw-slate", async (req, res) => {
  try {
    const { prompt, topic, question, currentBoardContent } = req.body;
    if (!prompt || typeof prompt !== "string") {
      res.status(400).json({ error: "Missing drawing prompt or command." });
      return;
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are Slate Master, an expert chalkboard teacher, scientific illustrator, and geometric draftsman.
When a student orders or asks you to draw something (e.g. math graphs, chemical formulas, biology diagrams, physics setups, geography maps, geometry figures, step-by-step equation proofs, architectural blueprints, or cute cartoon sketches), you generate precise, beautiful chalkboard chalk strokes.

Coordinate System:
- All points MUST be normalized integers from x: 0 to 1000 and y: 0 to 1000.
- Center of canvas is (500, 500). Keep the primary illustration well-framed within 100 <= x <= 900 and 100 <= y <= 900.
- Chalk colors available:
  * "#F5F1E6" (Classic Chalk White - main contours & handwriting)
  * "#E8C468" (Butter Yellow - highlights, vertices, important headers)
  * "#81D4FA" (Sky Cyan - coordinate axes, water, orbits, arrows)
  * "#8FBF8A" (Sage Green - nature, labels, correct checks)
  * "#FF8A80" (Coral Pink - nucleus, emphasis, angles)
  * "#CE93D8" (Soft Purple - secondary orbits, shading)
  * "#FFB74D" (Warm Orange - energy, sun, rays)

Stroke guidelines:
- Break the drawing into logical sequence strokes (12 to 50 strokes total for rich diagrams).
- For smooth curves (circles, arcs, parabolas, waves, eyes), generate 8 to 25 connected points per stroke.
- For straight lines, axis arrows, or polygon edges, generate 2 to 4 connected points per stroke.
- For handwritten labels, text, or equations, trace out the letter/number strokes with 4 to 12 points each.
- Width: standard chalk is width 3.5, bold highlights width 5, fine details width 2.5.
- Provide a clear title, 1-2 sentence description, category, and educational insight.`;

    const userPrompt = `Student drawing order: "${prompt}"
Context topic: ${topic || "General"}
Context question: ${question || "Open Board"}

Generate the complete chalkboard chalk drawing stroke sequence.
Ensure it is visually complete, elegant, and clearly drawn. Return JSON matching the schema.`;

    const { response } = await callGenerateContentWithFallback(ai, {
      contents: [{ parts: [{ text: userPrompt }] }],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: {
              type: Type.STRING,
              description: "Title of the illustration drawn.",
            },
            description: {
              type: Type.STRING,
              description: "Short summary of what was drawn on the slate.",
            },
            category: {
              type: Type.STRING,
              description: "Category (e.g. Mathematics, Science, Art, Diagram, Step-by-Step).",
            },
            educationalInsight: {
              type: Type.STRING,
              description: "Fascinating educational insight or rule related to what was drawn.",
            },
            stepNotes: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3-5 step-by-step explanations of the drawing process.",
            },
            strokes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  color: {
                    type: Type.STRING,
                    description: "Hex chalk color code like #F5F1E6, #E8C468, #81D4FA, #8FBF8A, etc.",
                  },
                  width: {
                    type: Type.NUMBER,
                    description: "Stroke line width between 2 and 6.",
                  },
                  label: {
                    type: Type.STRING,
                    description: "Short label for this drawing action e.g. 'Left orbit arc', 'Y-axis'.",
                  },
                  points: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        x: { type: Type.NUMBER, description: "X coordinate 0 to 1000" },
                        y: { type: Type.NUMBER, description: "Y coordinate 0 to 1000" },
                      },
                      required: ["x", "y"],
                    },
                  },
                },
                required: ["color", "width", "points"],
              },
            },
          },
          required: ["title", "description", "category", "strokes"],
        },
      },
    });

    const parsed = safeParseJson<{
      title?: string;
      description?: string;
      category?: string;
      educationalInsight?: string;
      stepNotes?: string[];
      strokes?: Array<{
        color?: string;
        width?: number;
        label?: string;
        points?: Array<{ x: number; y: number }>;
      }>;
    }>(response.text || "{}", {
      title: "Chalkboard Illustration",
      description: `Illustration of ${prompt}`,
      category: "Illustration",
      educationalInsight: "Visual chalkboard representations improve conceptual understanding.",
      stepNotes: ["Outlined core geometry", "Added details and annotations", "Finished chalkboard render"],
      strokes: [],
    });

    // Clean and validate strokes
    let cleanStrokes = (parsed.strokes || [])
      .filter((s) => s && Array.isArray(s.points) && s.points.length > 0)
      .map((s) => {
        const strokeColor = s.color && s.color.startsWith("#") ? s.color : "#F5F1E6";
        const strokeWidth = typeof s.width === "number" && s.width >= 1 && s.width <= 12 ? s.width : 4;
        const validPoints = (s.points || [])
          .filter((p) => typeof p.x === "number" && typeof p.y === "number" && !isNaN(p.x) && !isNaN(p.y))
          .map((p) => ({
            x: Math.max(0, Math.min(1000, p.x)),
            y: Math.max(0, Math.min(1000, p.y)),
          }));

        return {
          color: strokeColor,
          width: strokeWidth,
          label: s.label || "",
          points: validPoints,
        };
      })
      .filter((s) => s.points.length > 0);

    // Fallback if AI generated 0 valid strokes: build a clean geometric drawing
    if (cleanStrokes.length === 0) {
      cleanStrokes = generateFallbackChalkStrokes(prompt);
    }

    res.json({
      title: parsed.title || `Drawing: ${prompt}`,
      description: parsed.description || "AI chalkboard sketch",
      category: parsed.category || "General",
      educationalInsight: parsed.educationalInsight || "Visual representations build strong intuition!",
      stepNotes: parsed.stepNotes || ["Initial sketch", "Details", "Finished diagram"],
      strokes: cleanStrokes,
    });
  } catch (error: any) {
    console.error("Error auto-drawing on slate:", error);
    res.status(500).json({
      error: error.message || "Failed to auto-draw on slate.",
    });
  }
});

// Helper for programmatic chalkboard fallback diagrams
function generateFallbackChalkStrokes(prompt: string): Array<{ color: string; width: number; label: string; points: { x: number; y: number }[] }> {
  const pLower = prompt.toLowerCase();
  const strokes: Array<{ color: string; width: number; label: string; points: { x: number; y: number }[] }> = [];

  if (pLower.includes("parabola") || pLower.includes("graph") || pLower.includes("quadratic")) {
    // Axes
    strokes.push({
      color: "#81D4FA",
      width: 3.5,
      label: "X Axis",
      points: [{ x: 100, y: 650 }, { x: 900, y: 650 }],
    });
    strokes.push({
      color: "#81D4FA",
      width: 3.5,
      label: "Y Axis",
      points: [{ x: 500, y: 150 }, { x: 500, y: 850 }],
    });

    // Parabola curve y = a(x - h)^2 + k
    const parabolaPoints: { x: number; y: number }[] = [];
    for (let x = 200; x <= 800; x += 15) {
      const normX = (x - 500) / 100;
      const normY = normX * normX * 0.45;
      const y = 650 - (200 - normY * 100);
      if (y >= 160 && y <= 840) {
        parabolaPoints.push({ x, y });
      }
    }
    strokes.push({
      color: "#E8C468",
      width: 4.5,
      label: "Parabola y = x² - 2",
      points: parabolaPoints,
    });

    // Vertex point
    strokes.push({
      color: "#FF8A80",
      width: 6,
      label: "Vertex (0, -2)",
      points: [{ x: 496, y: 450 }, { x: 504, y: 450 }],
    });
  } else if (pLower.includes("atom") || pLower.includes("molecule") || pLower.includes("orbit")) {
    // Central Nucleus
    const nucleusPts: { x: number; y: number }[] = [];
    for (let angle = 0; angle <= Math.PI * 2 + 0.1; angle += 0.3) {
      nucleusPts.push({
        x: 500 + Math.cos(angle) * 35,
        y: 500 + Math.sin(angle) * 35,
      });
    }
    strokes.push({ color: "#FF8A80", width: 5, label: "Nucleus", points: nucleusPts });

    // Orbits 1, 2, 3
    for (let orbit = 0; orbit < 3; orbit++) {
      const rot = (orbit * Math.PI) / 3;
      const orbitPts: { x: number; y: number }[] = [];
      for (let t = 0; t <= Math.PI * 2 + 0.1; t += 0.2) {
        const rx = 240 * Math.cos(t);
        const ry = 85 * Math.sin(t);
        const x = 500 + rx * Math.cos(rot) - ry * Math.sin(rot);
        const y = 500 + rx * Math.sin(rot) + ry * Math.cos(rot);
        orbitPts.push({ x, y });
      }
      const color = orbit === 0 ? "#81D4FA" : orbit === 1 ? "#E8C468" : "#8FBF8A";
      strokes.push({ color, width: 3.5, label: `Electron Orbit ${orbit + 1}`, points: orbitPts });
    }
  } else {
    // Default star / badge diagram
    const starPts: { x: number; y: number }[] = [];
    const pointsCount = 5;
    for (let i = 0; i <= pointsCount * 2; i++) {
      const r = i % 2 === 0 ? 220 : 95;
      const angle = (i * Math.PI) / pointsCount - Math.PI / 2;
      starPts.push({
        x: 500 + Math.cos(angle) * r,
        y: 480 + Math.sin(angle) * r,
      });
    }
    strokes.push({
      color: "#E8C468",
      width: 4.5,
      label: "Star Outline",
      points: starPts,
    });

    // Baseline caption underline
    strokes.push({
      color: "#F5F1E6",
      width: 3.5,
      label: "Chalk Underline",
      points: [{ x: 300, y: 780 }, { x: 700, y: 780 }],
    });
  }

  return strokes;
}


async function startServer() {
  const server = http.createServer(app);

  // Setup WebSocket Server for Live API Voice Conversations
  const wss = new WebSocketServer({ server, path: "/api/live" });

  wss.on("connection", async (clientWs, req) => {
    console.log("[Live API] Client connected to live voice tutor.");

    let liveSession: any = null;

    try {
      const ai = getGeminiClient();
      liveSession = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: "Zephyr",
              },
            },
          },
          systemInstruction:
            "You are a supportive, encouraging, expert chalkboard tutor named Slate Tutor. You talk naturally and directly to help students solve problems, practice handwriting, understand math, science, language, and concept steps. Keep your spoken explanations conversational, friendly, concise, and clear.",
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ audio: audioData }));
            }
            if (message.serverContent?.interrupted && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ interrupted: true }));
            }
            if (message.serverContent?.turnComplete && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ turnComplete: true }));
            }
          },
          onclose: () => {
            console.log("[Live API] Gemini session closed.");
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ closed: true }));
            }
          },
          onerror: (err) => {
            console.error("[Live API] Gemini session error:", err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ error: err?.message || "Live API error occurred" }));
            }
          },
        },
      });

      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({ ready: true }));
      }

      clientWs.on("message", (data) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (parsed.audio && liveSession) {
            liveSession.sendRealtimeInput({
              audio: { data: parsed.audio, mimeType: "audio/pcm;rate=16000" },
            });
          }
          if (parsed.image && liveSession) {
            const cleanImage = parsed.image.replace(/^data:image\/\w+;base64,/, "");
            liveSession.sendRealtimeInput({
              video: { data: cleanImage, mimeType: "image/jpeg" },
            });
          }
          if (parsed.text && liveSession) {
            liveSession.sendRealtimeInput({
              text: parsed.text,
            });
          }
        } catch (err) {
          console.error("[Live API] Error parsing client message:", err);
        }
      });

      clientWs.on("close", () => {
        console.log("[Live API] Client disconnected.");
        if (liveSession) {
          try {
            liveSession.close();
          } catch (e) {}
        }
      });
    } catch (err: any) {
      console.error("[Live API] Failed to connect to Gemini Live:", err);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            error: err?.message || "Failed to initialize Live voice session with Gemini Live API.",
          })
        );
        clientWs.close();
      }
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Slate Chalkboard Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
