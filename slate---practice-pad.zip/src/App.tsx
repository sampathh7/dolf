import React, { useState, useEffect, useRef } from 'react';
import ChalkCanvas, { CHALK_COLORS } from './components/ChalkCanvas';
import FeedbackPanel from './components/FeedbackPanel';
import HeaderToolbar from './components/HeaderToolbar';
import LiveVoiceTutor from './components/LiveVoiceTutor';
import ColorSettingsModal from './components/ColorSettingsModal';
import DrawingVisualizerModal from './components/DrawingVisualizerModal';
import AutoDrawModal from './components/AutoDrawModal';
import MascotBuddy from './components/MascotBuddy';
import { Stroke, FeedbackResult, FeedbackHistoryItem, BoardThemeOption, GeneratedDrawingImage, AutoDrawResult } from './types';
import { AiDrawingRunner, AiDrawingState } from './utils/aiDrawingRunner';
import { 
  getStoredBoardTheme, 
  saveBoardTheme, 
  getStoredChalkColor, 
  saveChalkColor,
  BOARD_THEMES 
} from './utils/themes';
import { Sparkles, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [mode, setMode] = useState<'pen' | 'erase'>('pen');
  const [boardTheme, setBoardTheme] = useState<BoardThemeOption>(() => getStoredBoardTheme());
  const [activeColor, setActiveColorState] = useState<string>(() => getStoredChalkColor());
  const [strokeWidth, setStrokeWidth] = useState<number>(4);
  const [isColorSettingsOpen, setIsColorSettingsOpen] = useState(false);
  const [isDrawingVisualizerOpen, setIsDrawingVisualizerOpen] = useState(false);
  const [visualizerSnapshot, setVisualizerSnapshot] = useState<string | null>(null);

  // AI Auto-Draw State
  const [isAutoDrawOpen, setIsAutoDrawOpen] = useState(false);
  const [autoDrawInitialPrompt, setAutoDrawInitialPrompt] = useState<string>('');
  const [aiDrawingState, setAiDrawingState] = useState<AiDrawingState | undefined>(undefined);
  const aiDrawingRunnerRef = useRef<AiDrawingRunner>(new AiDrawingRunner());

  // Setup AI drawing runner callbacks
  useEffect(() => {
    const runner = aiDrawingRunnerRef.current;
    runner.setCallbacks(
      (state) => {
        setAiDrawingState({ ...state });
      },
      (updatedStrokes) => {
        setStrokes(updatedStrokes);
      },
      (result) => {
        showToast(`AI finished drawing: "${result.title}"`, 'success', 3500);
      }
    );
  }, []);

  const handleOpenAutoDraw = (initialPrompt?: string) => {
    setAutoDrawInitialPrompt(initialPrompt || '');
    setIsAutoDrawOpen(true);
  };

  const handleStartAutoDraw = (
    result: AutoDrawResult, 
    options: { animated: boolean; speed: number; clearBoard: boolean }
  ) => {
    // Get canvas dimensions from window or fallback to standard 1200x800
    const canvasWidth = window.innerWidth > 0 ? window.innerWidth : 1200;
    const canvasHeight = window.innerHeight > 0 ? window.innerHeight : 800;

    aiDrawingRunnerRef.current.startDrawing(result, {
      ...options,
      canvasWidth,
      canvasHeight,
      existingStrokes: strokes,
    });
  };

  const setActiveColor = (color: string) => {
    setActiveColorState(color);
    saveChalkColor(color);
  };

  const handleSelectBoardTheme = (theme: BoardThemeOption) => {
    setBoardTheme(theme);
    saveBoardTheme(theme.id);
    showToast(`Chalkboard theme changed to ${theme.name}`, 'info', 2000);
  };

  const handleOpenDrawingVisualizer = () => {
    if (strokes.length === 0) {
      showToast('Draw a sketch or diagram on the chalkboard first!', 'info', 3000);
      return;
    }
    const snapshot = getCanvasSnapshotRef.current ? getCanvasSnapshotRef.current() : null;
    if (!snapshot) {
      showToast('Could not capture board canvas snapshot.', 'error', 3000);
      return;
    }
    setVisualizerSnapshot(snapshot);
    setIsDrawingVisualizerOpen(true);
  };

  const [topic, setTopic] = useState<string>('Quadratic Equations');
  const [questions, setQuestions] = useState<string[]>([]);
  const [activeQuestion, setActiveQuestion] = useState<string>('');
  const [isGeneratingQuestions, setIsGeneratingQuestions] = useState(false);

  const [feedback, setFeedback] = useState<FeedbackResult | null>(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);

  const getCanvasSnapshotRef = useRef<(() => string | null) | null>(null);

  // Practice score history state persisted in localStorage
  const [history, setHistory] = useState<FeedbackHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('slate_practice_history');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return [];
  });

  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'info' | 'error' | 'success' } | null>(null);

  const showToast = (text: string, type: 'info' | 'error' | 'success' = 'info', duration = 3500) => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage((cur) => (cur?.text === text ? null : cur));
    }, duration);
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem('slate_practice_history');
    } catch {
      // ignore
    }
    showToast('Progress history reset.', 'info');
  };

  // Generate drill questions for the topic
  const handleGenerateQuestions = async () => {
    if (!topic.trim() || isGeneratingQuestions) return;
    setIsGeneratingQuestions(true);
    showToast(`Generating drills for "${topic}"…`, 'info', 2500);

    try {
      const res = await fetch('/api/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: topic.trim() }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to generate questions');
      }

      const data = await res.json();
      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        setActiveQuestion(data.questions[0]);
        showToast('Drill questions ready! Select one to practice.', 'success');
      } else {
        showToast('No questions returned. Try another topic.', 'error');
      }
    } catch (error: any) {
      console.error(error);
      showToast(error.message || 'Error generating questions.', 'error');
    } finally {
      setIsGeneratingQuestions(false);
    }
  };

  // Submit canvas image for vision review
  const handleSubmitWork = async (canvasImageBase64: string) => {
    if (strokes.length === 0) {
      showToast('Please write your solution on the chalkboard first.', 'info');
      return;
    }

    setIsChecking(true);
    showToast('Gemini is inspecting your chalkboard solution…', 'info', 4000);

    try {
      const res = await fetch('/api/check-work', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: canvasImageBase64,
          topic: topic.trim(),
          question: activeQuestion,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to analyze handwriting.');
      }

      const result: FeedbackResult = await res.json();
      setFeedback(result);
      setIsFeedbackOpen(true);

      // Record to history for progress tracking
      const newHistoryItem: FeedbackHistoryItem = {
        id: `hist-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        topic: topic.trim() || 'General Practice',
        question: activeQuestion || undefined,
        score: result.overall_score,
        date: Date.now(),
        mistakesCount: (result.mistakes || []).length,
      };

      setHistory((prev) => {
        const updated = [...prev, newHistoryItem];
        try {
          localStorage.setItem('slate_practice_history', JSON.stringify(updated));
        } catch {
          // ignore
        }
        return updated;
      });

      if (result.mistakes.length === 0) {
        showToast(`Flawless! Scored ${result.overall_score}/100 🎯`, 'success');
      } else {
        showToast(`Feedback ready: ${result.mistakes.length} correction(s) identified.`, 'info');
      }
    } catch (error: any) {
      console.error(error);
      showToast(error.message || 'Failed to check work. Check API configuration.', 'error');
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div 
      className="flex flex-col h-screen w-screen text-[#F5F1E6] overflow-hidden font-sans transition-colors duration-300"
      style={{ backgroundColor: boardTheme.appBackground }}
    >
      {/* Top Header Bar */}
      <HeaderToolbar
        topic={topic}
        setTopic={setTopic}
        questions={questions}
        activeQuestion={activeQuestion}
        setActiveQuestion={setActiveQuestion}
        onGenerateQuestions={handleGenerateQuestions}
        isGeneratingQuestions={isGeneratingQuestions}
        isFeedbackOpen={isFeedbackOpen}
        setIsFeedbackOpen={setIsFeedbackOpen}
        hasFeedback={Boolean(feedback)}
        history={history}
        onClearHistory={handleClearHistory}
        onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
        onOpenColorSettings={() => setIsColorSettingsOpen(true)}
        onOpenDrawingVisualizer={handleOpenDrawingVisualizer}
        onOpenAutoDraw={() => handleOpenAutoDraw()}
        boardTheme={boardTheme}
      />

      {/* Main Board & Feedback Panel */}
      <main className="flex-1 flex overflow-hidden relative">
        {/* Chalkboard Drawing Workspace */}
        <ChalkCanvas
          strokes={strokes}
          setStrokes={setStrokes}
          onSubmitWork={handleSubmitWork}
          isChecking={isChecking}
          activeColor={activeColor}
          setActiveColor={setActiveColor}
          strokeWidth={strokeWidth}
          setStrokeWidth={setStrokeWidth}
          mode={mode}
          setMode={setMode}
          boardTheme={boardTheme}
          onOpenColorSettings={() => setIsColorSettingsOpen(true)}
          onOpenDrawingVisualizer={handleOpenDrawingVisualizer}
          onOpenAutoDraw={() => handleOpenAutoDraw()}
          aiDrawingState={aiDrawingState}
          onPauseAiDrawing={() => aiDrawingRunnerRef.current.pause()}
          onResumeAiDrawing={() => aiDrawingRunnerRef.current.resume()}
          onSkipAiDrawing={() => aiDrawingRunnerRef.current.skipToEnd()}
          onCancelAiDrawing={() => {
            aiDrawingRunnerRef.current.cancel();
            setAiDrawingState(undefined);
          }}
          getCanvasSnapshotRef={getCanvasSnapshotRef}
          onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
        />

        {/* Feedback Side Panel */}
        <FeedbackPanel
          feedback={feedback}
          isOpen={isFeedbackOpen}
          onClose={() => setIsFeedbackOpen(false)}
          topic={topic}
          activeQuestion={activeQuestion}
          onOpenDrawingVisualizer={handleOpenDrawingVisualizer}
          onOpenAutoDraw={(prompt) => handleOpenAutoDraw(prompt)}
        />

        {/* Real-time Voice Tutor Live Session Modal */}
        <LiveVoiceTutor
          isOpen={isLiveVoiceOpen}
          onClose={() => setIsLiveVoiceOpen(false)}
          getCanvasImage={() => (getCanvasSnapshotRef.current ? getCanvasSnapshotRef.current() : null)}
          topic={topic}
          question={activeQuestion}
          onOpenAutoDraw={(prompt) => handleOpenAutoDraw(prompt)}
        />

        {/* Board & Chalk Color Settings Modal */}
        <ColorSettingsModal
          isOpen={isColorSettingsOpen}
          onClose={() => setIsColorSettingsOpen(false)}
          currentBoardTheme={boardTheme}
          onSelectBoardTheme={handleSelectBoardTheme}
          activeChalkColor={activeColor}
          onSelectChalkColor={setActiveColor}
        />

        {/* AI Drawing Visualizer Modal (Chalk sketch -> Real Image) */}
        <DrawingVisualizerModal
          isOpen={isDrawingVisualizerOpen}
          onClose={() => setIsDrawingVisualizerOpen(false)}
          canvasSnapshot={visualizerSnapshot}
          topic={topic}
          question={activeQuestion}
          onImageGenerated={(item) => {
            showToast(`✨ Generated image for "${item.subject}"!`, 'success', 3000);
          }}
        />

        {/* AI Auto-Draw on Slate Modal */}
        <AutoDrawModal
          isOpen={isAutoDrawOpen}
          onClose={() => setIsAutoDrawOpen(false)}
          onStartDrawing={handleStartAutoDraw}
          topic={topic}
          question={activeQuestion}
          initialPrompt={autoDrawInitialPrompt}
          hasExistingStrokes={strokes.length > 0}
        />

        {/* Floating Cartoon Mascot Companion on Chalkboard */}
        <MascotBuddy
          score={feedback?.overall_score}
          praise={feedback?.praise}
          topic={topic}
          question={activeQuestion}
          hasFeedback={Boolean(feedback)}
          onOpenFeedback={() => setIsFeedbackOpen(true)}
        />

        {/* Global Floating Toast Banner */}
        {toastMessage && (
          <div
            id="statusBanner"
            className={`absolute left-1/2 -translate-x-1/2 bottom-6 z-40 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-medium shadow-2xl flex items-center gap-2 border animate-in fade-in slide-in-from-bottom-2 duration-200 ${
              toastMessage.type === 'error'
                ? 'bg-[#E2725B] text-[#182821] border-[#E2725B]'
                : toastMessage.type === 'success'
                ? 'bg-[#8FBF8A] text-[#182821] border-[#8FBF8A]'
                : 'bg-[#213A30] text-[#F5F1E6] border-[#F5F1E6]/20'
            }`}
          >
            {toastMessage.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0" />
            ) : toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <Sparkles className="w-4 h-4 text-[#E8C468] shrink-0" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        )}
      </main>
    </div>
  );
}
