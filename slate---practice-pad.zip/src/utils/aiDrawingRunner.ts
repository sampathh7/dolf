import { Stroke, AutoDrawResult, AutoDrawStroke } from '../types';
import { chalkAudio } from './chalkAudio';

export interface AiDrawingState {
  isDrawing: boolean;
  isPaused: boolean;
  currentStrokeIndex: number;
  totalStrokes: number;
  currentStepDescription: string;
  activeCoordinates: { x: number; y: number } | null;
  activeColor: string;
  title: string;
  educationalInsight?: string;
}

export class AiDrawingRunner {
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private cancelRequested: boolean = false;
  private skipToEndRequested: boolean = false;

  private onStateChangeCallback?: (state: AiDrawingState) => void;
  private onStrokesUpdatedCallback?: (strokes: Stroke[]) => void;
  private onCompletedCallback?: (result: AutoDrawResult) => void;

  public setCallbacks(
    onStateChange: (state: AiDrawingState) => void,
    onStrokesUpdated: (strokes: Stroke[]) => void,
    onCompleted: (result: AutoDrawResult) => void
  ) {
    this.onStateChangeCallback = onStateChange;
    this.onStrokesUpdatedCallback = onStrokesUpdated;
    this.onCompletedCallback = onCompleted;
  }

  public pause() {
    this.isPaused = true;
    chalkAudio.stopStrokeSound();
  }

  public resume() {
    this.isPaused = false;
  }

  public cancel() {
    this.cancelRequested = true;
    this.isRunning = false;
    chalkAudio.stopStrokeSound();
  }

  public skipToEnd() {
    this.skipToEndRequested = true;
  }

  // Convert 0..1000 normalized points into actual container coordinates
  private scalePoints(
    points: { x: number; y: number }[],
    canvasWidth: number,
    canvasHeight: number
  ): { x: number; y: number; pressure: number }[] {
    // Add padding margins so drawing stays nicely centered on chalkboard
    const padX = canvasWidth * 0.08;
    const padY = canvasHeight * 0.08;
    const availableW = canvasWidth - padX * 2;
    const availableH = canvasHeight - padY * 2;

    return points.map((p, idx) => {
      const x = padX + (p.x / 1000) * availableW;
      const y = padY + (p.y / 1000) * availableH;
      // Natural pressure variation along the stroke
      const progress = points.length > 1 ? idx / (points.length - 1) : 0.5;
      const pressure = 0.5 + Math.sin(progress * Math.PI) * 0.35 + (Math.random() * 0.1 - 0.05);
      return { x, y, pressure };
    });
  }

  public async startDrawing(
    result: AutoDrawResult,
    options: {
      animated: boolean;
      speed: number;
      clearBoard: boolean;
      canvasWidth: number;
      canvasHeight: number;
      existingStrokes: Stroke[];
    }
  ): Promise<void> {
    this.isRunning = true;
    this.isPaused = false;
    this.cancelRequested = false;
    this.skipToEndRequested = false;

    const { animated, speed, clearBoard, canvasWidth, canvasHeight, existingStrokes } = options;

    let currentStrokes: Stroke[] = clearBoard ? [] : [...existingStrokes];
    const totalStrokes = result.strokes.length;

    // Instant mode
    if (!animated) {
      chalkAudio.playChalkTap('pen');
      result.strokes.forEach((autoStroke, idx) => {
        const scaledPts = this.scalePoints(autoStroke.points, canvasWidth, canvasHeight);
        currentStrokes.push({
          id: `ai_stroke_${Date.now()}_${idx}`,
          type: autoStroke.type || 'pen',
          color: autoStroke.color || '#F5F1E6',
          width: autoStroke.width || 4,
          points: scaledPts,
        });
      });

      this.onStrokesUpdatedCallback?.([...currentStrokes]);
      this.onStateChangeCallback?.({
        isDrawing: false,
        isPaused: false,
        currentStrokeIndex: totalStrokes,
        totalStrokes,
        currentStepDescription: 'Completed',
        activeCoordinates: null,
        activeColor: '#E8C468',
        title: result.title,
        educationalInsight: result.educationalInsight,
      });

      this.onCompletedCallback?.(result);
      this.isRunning = false;
      return;
    }

    // Animated mode: draw stroke by stroke, point by point
    const baseDelay = Math.max(8, Math.floor(28 / speed));

    for (let sIdx = 0; sIdx < totalStrokes; sIdx++) {
      if (this.cancelRequested) break;

      const autoStroke = result.strokes[sIdx];
      const scaledPts = this.scalePoints(autoStroke.points, canvasWidth, canvasHeight);
      const strokeColor = autoStroke.color || '#F5F1E6';
      const strokeWidth = autoStroke.width || 4;
      const strokeType = autoStroke.type || 'pen';

      const strokeDescription =
        autoStroke.label ||
        (result.stepNotes && result.stepNotes[sIdx % result.stepNotes.length]) ||
        `Drawing stroke ${sIdx + 1} of ${totalStrokes}`;

      this.onStateChangeCallback?.({
        isDrawing: true,
        isPaused: this.isPaused,
        currentStrokeIndex: sIdx + 1,
        totalStrokes,
        currentStepDescription: strokeDescription,
        activeCoordinates: scaledPts[0] ? { x: scaledPts[0].x, y: scaledPts[0].y } : null,
        activeColor: strokeColor,
        title: result.title,
        educationalInsight: result.educationalInsight,
      });

      // If skip was clicked, append entire stroke at once
      if (this.skipToEndRequested) {
        currentStrokes.push({
          id: `ai_stroke_${Date.now()}_${sIdx}`,
          type: strokeType,
          color: strokeColor,
          width: strokeWidth,
          points: scaledPts,
        });
        this.onStrokesUpdatedCallback?.([...currentStrokes]);
        continue;
      }

      // Start new active stroke
      const strokeId = `ai_stroke_${Date.now()}_${sIdx}`;
      const newStroke: Stroke = {
        id: strokeId,
        type: strokeType,
        color: strokeColor,
        width: strokeWidth,
        points: [scaledPts[0]],
      };

      currentStrokes.push(newStroke);
      this.onStrokesUpdatedCallback?.([...currentStrokes]);

      chalkAudio.startStrokeSound(strokeType, scaledPts[0].x, scaledPts[0].y);

      // Animate points
      for (let pIdx = 1; pIdx < scaledPts.length; pIdx++) {
        if (this.cancelRequested) break;

        // Handle pause
        while (this.isPaused && !this.cancelRequested && !this.skipToEndRequested) {
          await new Promise((r) => setTimeout(r, 100));
        }

        if (this.skipToEndRequested) {
          newStroke.points = scaledPts;
          this.onStrokesUpdatedCallback?.([...currentStrokes]);
          break;
        }

        const pt = scaledPts[pIdx];
        newStroke.points.push(pt);
        this.onStrokesUpdatedCallback?.([...currentStrokes]);

        this.onStateChangeCallback?.({
          isDrawing: true,
          isPaused: this.isPaused,
          currentStrokeIndex: sIdx + 1,
          totalStrokes,
          currentStepDescription: strokeDescription,
          activeCoordinates: { x: pt.x, y: pt.y },
          activeColor: strokeColor,
          title: result.title,
          educationalInsight: result.educationalInsight,
        });

        // Tactile chalk audio sound during stroke
        chalkAudio.updateStrokeSound(pt.x, pt.y, pt.pressure, strokeType);

        await new Promise((r) => setTimeout(r, baseDelay));
      }

      chalkAudio.stopStrokeSound();

      // Brief breath pause between strokes
      if (!this.skipToEndRequested) {
        await new Promise((r) => setTimeout(r, Math.max(30, Math.floor(120 / speed))));
      }
    }

    chalkAudio.stopStrokeSound();

    if (!this.cancelRequested) {
      chalkAudio.playChalkTap('pen');
      this.onCompletedCallback?.(result);
    }

    this.onStateChangeCallback?.({
      isDrawing: false,
      isPaused: false,
      currentStrokeIndex: totalStrokes,
      totalStrokes,
      currentStepDescription: 'Finished chalkboard illustration!',
      activeCoordinates: null,
      activeColor: '#E8C468',
      title: result.title,
      educationalInsight: result.educationalInsight,
    });

    this.isRunning = false;
  }
}
