import React, { useState } from 'react';
import { 
  Sparkles, 
  Mic, 
  MicOff, 
  BookOpen, 
  HelpCircle, 
  Check, 
  ListPlus,
  Compass,
  Key,
  Radio,
  Palette,
  X,
  Pencil
} from 'lucide-react';
import ProgressTracker from './ProgressTracker';
import { FeedbackHistoryItem, BoardThemeOption } from '../types';

interface HeaderToolbarProps {
  topic: string;
  setTopic: (t: string) => void;
  questions: string[];
  activeQuestion: string;
  setActiveQuestion: (q: string) => void;
  onGenerateQuestions: () => void;
  isGeneratingQuestions: boolean;
  isFeedbackOpen: boolean;
  setIsFeedbackOpen: (open: boolean) => void;
  hasFeedback: boolean;
  history: FeedbackHistoryItem[];
  onClearHistory: () => void;
  onOpenLiveVoice: () => void;
  onOpenColorSettings?: () => void;
  onOpenDrawingVisualizer?: () => void;
  onOpenAutoDraw?: () => void;
  boardTheme?: BoardThemeOption;
}

const PRESET_TOPICS = [
  'Quadratic Equations',
  'Organic Chemistry',
  'Spanish Preterite',
  'Physics Optics',
  'Calculus Integrals',
  'Photosynthesis',
];

export default function HeaderToolbar({
  topic,
  setTopic,
  questions,
  activeQuestion,
  setActiveQuestion,
  onGenerateQuestions,
  isGeneratingQuestions,
  isFeedbackOpen,
  setIsFeedbackOpen,
  hasFeedback,
  history,
  onClearHistory,
  onOpenLiveVoice,
  onOpenColorSettings,
  onOpenDrawingVisualizer,
  onOpenAutoDraw,
  boardTheme,
}: HeaderToolbarProps) {
  const [isMicActive, setIsMicActive] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);

  const toggleMic = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isMicActive) {
      setIsMicActive(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onstart = () => setIsMicActive(true);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        setTopic(transcript);
      }
    };
    recognition.onerror = () => setIsMicActive(false);
    recognition.onend = () => setIsMicActive(false);

    recognition.start();
  };

  return (
    <header 
      className="border-b border-[#F5F1E6]/10 flex flex-col shrink-0 z-20 transition-colors duration-300"
      style={{ backgroundColor: boardTheme?.appBackground || '#182821' }}
    >
      {/* Top Navbar */}
      <div className="px-4 py-3 flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap">
        {/* Logo & Title */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-[#E8C468]/20 border border-[#E8C468]/40 flex items-center justify-center text-[#E8C468]">
            <BookOpen className="w-4 h-4" />
          </div>
          <div>
            <span className="font-hand font-bold text-2xl text-[#E8C468] tracking-wide leading-none">
              Slate
            </span>
            <span className="hidden sm:inline-block text-[11px] font-medium text-[#F5F1E6]/50 ml-2 uppercase tracking-wider">
              Practice Pad
            </span>
          </div>
        </div>

        {/* Topic Input Bar */}
        <div className="flex-1 min-w-[240px] max-w-2xl flex items-center gap-2">
          <div className="relative flex-1">
            <input
              id="topicInput"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') onGenerateQuestions();
              }}
              placeholder="What topic are you practicing? (e.g. Algebra, French, Physics)"
              className="w-full bg-[#213A30] border border-[#F5F1E6]/15 rounded-xl pl-3 pr-10 py-2 text-xs sm:text-sm text-[#F5F1E6] placeholder-[#F5F1E6]/40 focus:outline-none focus:border-[#E8C468] transition-colors"
            />
            <button
              id="micTopicBtn"
              onClick={toggleMic}
              className={`absolute right-1.5 top-1.5 p-1.5 rounded-lg transition-all ${
                isMicActive
                  ? 'bg-[#E2725B] text-white animate-pulse'
                  : 'text-[#F5F1E6]/50 hover:text-[#F5F1E6]'
              }`}
              title={isMicActive ? 'Listening…' : 'Speak Topic'}
            >
              {isMicActive ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          <button
            id="genQuestionsBtn"
            onClick={onGenerateQuestions}
            disabled={!topic.trim() || isGeneratingQuestions}
            className="px-3.5 py-2 rounded-xl bg-[#213A30] hover:bg-[#2A473B] text-[#F5F1E6] border border-[#F5F1E6]/15 text-xs sm:text-sm font-medium flex items-center gap-1.5 shrink-0 transition-all disabled:opacity-40"
          >
            <ListPlus className={`w-4 h-4 text-[#E8C468] ${isGeneratingQuestions ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Get Practice Questions</span>
            <span className="sm:hidden">Drills</span>
          </button>
        </div>

        {/* Right Info, Progress Tracker & Drawer Toggle */}
        <div className="flex items-center gap-2 shrink-0">
          <ProgressTracker history={history} onClearHistory={onClearHistory} />

          {/* AI Auto-Draw Button */}
          {onOpenAutoDraw && (
            <button
              id="headerAutoDrawBtn"
              onClick={onOpenAutoDraw}
              className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#81D4FA]/20 to-[#8FBF8A]/20 hover:from-[#81D4FA]/30 hover:to-[#8FBF8A]/30 text-[#81D4FA] border border-[#81D4FA]/40 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#81D4FA]/10 transition-all hover:scale-[1.02]"
              title="Order AI to draw diagrams, formulas, and math graphs on slate"
            >
              <Pencil className="w-4 h-4 text-[#81D4FA]" />
              <span className="hidden sm:inline">AI Draw</span>
            </button>
          )}

          {/* Transform Drawing to Real Image Button */}
          {onOpenDrawingVisualizer && (
            <button
              id="headerDrawingVisualizerBtn"
              onClick={onOpenDrawingVisualizer}
              className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#E8C468]/20 to-[#E2725B]/20 hover:from-[#E8C468]/30 hover:to-[#E2725B]/30 text-[#E8C468] border border-[#E8C468]/40 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#E8C468]/10 transition-all hover:scale-[1.02]"
              title="Transform chalkboard sketch into an AI visual image (gemini-3.1-flash-image)"
            >
              <Sparkles className="w-4 h-4 text-[#E8C468]" />
              <span className="hidden sm:inline">AI Image</span>
            </button>
          )}

          {/* Real-time Voice Tutor Button (Gemini Live API) */}
          <button
            id="openLiveVoiceBtn"
            onClick={onOpenLiveVoice}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#2A473B] to-[#213A30] hover:from-[#355B4B] hover:to-[#2A473B] text-[#F5F1E6] border border-[#8FBF8A]/40 text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-[#8FBF8A]/10 transition-all hover:scale-[1.02]"
            title="Start live voice conversation with Gemini Live API (gemini-3.1-flash-live-preview)"
          >
            <Radio className="w-4 h-4 text-[#8FBF8A] animate-pulse" />
            <span className="hidden sm:inline font-medium text-[#8FBF8A]">Voice Tutor</span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#8FBF8A]/20 text-[#8FBF8A] font-mono uppercase font-bold">
              Live
            </span>
          </button>

          {/* Color & Theme Settings Button */}
          {onOpenColorSettings && (
            <button
              id="openColorSettingsBtn"
              onClick={onOpenColorSettings}
              className="px-3 py-2 rounded-xl bg-[#213A30] hover:bg-[#2A473B] text-[#F5F1E6] border border-[#F5F1E6]/15 text-xs font-medium flex items-center gap-1.5 transition-all hover:border-[#E8C468]/50"
              title="Change chalkboard background & chalk colors"
            >
              <Palette className="w-4 h-4 text-[#E8C468]" />
              <span className="hidden sm:inline">Theme</span>
              {boardTheme && (
                <span
                  className="w-2.5 h-2.5 rounded-full border border-white/20 hidden md:inline-block"
                  style={{ backgroundColor: boardTheme.preview }}
                  title={boardTheme.name}
                />
              )}
            </button>
          )}

          <button
            onClick={() => setShowInfoModal(true)}
            className="p-2 rounded-xl text-[#F5F1E6]/60 hover:text-[#F5F1E6] hover:bg-[#213A30] transition-colors"
            title="API & Setup Guide"
          >
            <HelpCircle className="w-5 h-5" />
          </button>

          <button
            onClick={() => setIsFeedbackOpen(!isFeedbackOpen)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isFeedbackOpen
                ? 'bg-[#E8C468] text-[#182821]'
                : hasFeedback
                ? 'bg-[#213A30] text-[#E8C468] border border-[#E8C468]/30 shadow-md shadow-[#E8C468]/10'
                : 'bg-[#213A30] text-[#F5F1E6]/70 border border-[#F5F1E6]/10 hover:text-[#F5F1E6]'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden md:inline">Tutor Feedback</span>
          </button>
        </div>
      </div>

      {/* Suggested Topics Pills (when no custom questions loaded) */}
      {questions.length === 0 && (
        <div className="px-4 py-1.5 bg-[#1C2B24]/50 border-t border-[#F5F1E6]/5 flex items-center gap-2 overflow-x-auto text-[11px] text-[#F5F1E6]/50">
          <Compass className="w-3.5 h-3.5 shrink-0 text-[#E8C468]/70" />
          <span className="shrink-0">Suggestions:</span>
          {PRESET_TOPICS.map((preset) => (
            <button
              key={preset}
              onClick={() => {
                setTopic(preset);
              }}
              className="shrink-0 px-2.5 py-0.5 rounded-full bg-[#213A30]/70 hover:bg-[#2A473B] text-[#F5F1E6]/70 hover:text-[#F5F1E6] border border-[#F5F1E6]/10 transition-colors"
            >
              {preset}
            </button>
          ))}
        </div>
      )}

      {/* Active Question Banner & Question Pills Carousel */}
      {questions.length > 0 && (
        <div className="px-4 py-2.5 bg-[#1C2B24] border-t border-[#F5F1E6]/10 space-y-2">
          {activeQuestion && (
            <div className="flex items-center justify-between gap-3 bg-[#E8C468]/10 border-l-4 border-[#E8C468] px-3.5 py-2 rounded-r-xl">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-[10px] font-bold uppercase tracking-wider bg-[#E8C468] text-[#182821] px-1.5 py-0.5 rounded shrink-0">
                  Current Drill
                </span>
                <span className="font-hand text-lg text-[#F5F1E6] truncate">
                  {activeQuestion}
                </span>
              </div>
              <button
                onClick={() => setActiveQuestion('')}
                className="text-[#F5F1E6]/50 hover:text-[#F5F1E6] shrink-0 p-1"
                title="Deselect Question"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-[#F5F1E6]/40 shrink-0">
              Drill Questions:
            </span>
            {questions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => setActiveQuestion(q)}
                className={`shrink-0 px-3 py-1 rounded-full text-xs transition-all flex items-center gap-1.5 ${
                  activeQuestion === q
                    ? 'bg-[#E8C468] text-[#182821] font-semibold shadow-md shadow-[#E8C468]/20'
                    : 'bg-[#213A30] text-[#F5F1E6]/80 hover:text-[#F5F1E6] border border-[#F5F1E6]/10 hover:border-[#E8C468]/40'
                }`}
              >
                {activeQuestion === q && <Check className="w-3.5 h-3.5" />}
                <span className="max-w-[280px] truncate">{q}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Info & API Key Help Modal */}
      {showInfoModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1C2B24] border border-[#F5F1E6]/15 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-[#E8C468]/20 text-[#E8C468]">
                  <Key className="w-5 h-5" />
                </div>
                <h3 className="font-hand text-2xl text-[#E8C468] font-bold">
                  Gemini API & Architecture
                </h3>
              </div>
              <button
                onClick={() => setShowInfoModal(false)}
                className="p-1 rounded-lg text-[#F5F1E6]/60 hover:text-[#F5F1E6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-[#F5F1E6]/80 space-y-2.5 leading-relaxed">
              <p>
                <strong>Slate Practice Pad</strong> is powered by Google's <span className="text-[#E8C468]">Gemini 3.7 Flash</span> multimodal model with full server-side proxying.
              </p>
              <div className="bg-[#182821] p-3 rounded-xl border border-[#F5F1E6]/10 space-y-1.5">
                <div className="font-semibold text-[#8FBF8A] flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  Automatic Key Injection
                </div>
                <p className="text-[#F5F1E6]/70">
                  In Google AI Studio, your <code className="text-[#E8C468]">GEMINI_API_KEY</code> is securely managed in your container environment and passed to the Express backend.
                </p>
              </div>
              <div className="bg-[#182821] p-3 rounded-xl border border-[#F5F1E6]/10 space-y-1.5">
                <div className="font-semibold text-[#E8C468]">
                  How to get an API Key for standalone use:
                </div>
                <p className="text-[#F5F1E6]/70">
                  Visit <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer" className="text-[#E8C468] underline font-medium">aistudio.google.com/apikey</a> to get a free key and place it in your <code className="text-[#E8C468]">.env</code> file.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowInfoModal(false)}
              className="w-full py-2.5 rounded-xl bg-[#E8C468] text-[#182821] font-semibold text-xs hover:bg-[#f0d182] transition-colors"
            >
              Got it, let's practice!
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
