import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  X, 
  Download, 
  RefreshCw, 
  Wand2, 
  Palette, 
  Lightbulb, 
  Image as ImageIcon, 
  Layers, 
  Check, 
  Sliders, 
  Copy, 
  ExternalLink,
  ChevronRight,
  Eye,
  Info,
  Maximize2
} from 'lucide-react';
import { DrawingImageStyle, GeneratedDrawingImage } from '../types';

interface DrawingVisualizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  canvasSnapshot: string | null;
  topic?: string;
  question?: string;
  onImageGenerated?: (item: GeneratedDrawingImage) => void;
}

interface StyleOption {
  id: DrawingImageStyle;
  label: string;
  icon: string;
  desc: string;
}

const STYLE_OPTIONS: StyleOption[] = [
  { id: 'illustration', label: 'Concept Art', icon: '🎨', desc: 'Vibrant modern digital illustration' },
  { id: 'realistic', label: 'Realistic Photo', icon: '📸', desc: 'Lifelike real-world photograph' },
  { id: 'watercolor', label: 'Watercolor', icon: '🖌️', desc: 'Soft artistic watercolor and ink washes' },
  { id: '3d-render', label: '3D Render', icon: '🪐', desc: 'Cinematic volumetric 3D Pixar/Unreal look' },
  { id: 'anime', label: 'Anime Style', icon: '🌌', desc: 'Luminous anime landscape & character art' },
  { id: 'chalk-masterpiece', label: 'Master Chalk', icon: '🖍️', desc: 'Rich colored pastel chalkboard mural' },
];

export default function DrawingVisualizerModal({
  isOpen,
  onClose,
  canvasSnapshot,
  topic,
  question,
  onImageGenerated,
}: DrawingVisualizerModalProps) {
  const [selectedStyle, setSelectedStyle] = useState<DrawingImageStyle>('illustration');
  const [customPrompt, setCustomPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<GeneratedDrawingImage | null>(null);
  const [viewMode, setViewMode] = useState<'split' | 'ai-only' | 'drawing-only'>('split');
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  // Trigger generation whenever modal opens with fresh snapshot
  useEffect(() => {
    if (isOpen && canvasSnapshot && !currentResult && !isLoading) {
      handleGenerate();
    }
  }, [isOpen, canvasSnapshot]);

  // Loading animation step cycler
  useEffect(() => {
    let timer: any;
    if (isLoading) {
      timer = setInterval(() => {
        setLoadingStep((prev) => (prev % 3) + 1);
      }, 2400);
    }
    return () => clearInterval(timer);
  }, [isLoading]);

  if (!isOpen) return null;

  const handleGenerate = async (overrideStyle?: DrawingImageStyle) => {
    if (!canvasSnapshot) {
      setError('Please draw something on the chalkboard first!');
      return;
    }

    const styleToUse = overrideStyle || selectedStyle;
    setIsLoading(true);
    setError(null);
    setLoadingStep(1);

    try {
      const res = await fetch('/api/generate-drawing-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: canvasSnapshot,
          style: styleToUse,
          topic,
          question,
          customPrompt: customPrompt.trim() || undefined,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with status ${res.status}`);
      }

      const data = await res.json();
      
      const newGeneratedItem: GeneratedDrawingImage = {
        id: `gen-img-${Date.now()}`,
        imageUrl: data.imageUrl,
        originalCanvasSnapshot: canvasSnapshot,
        subject: data.subject || 'Student Drawing',
        detailedDescription: data.detailedDescription || 'Drawing visualization.',
        imagePrompt: data.imagePrompt || '',
        style: styleToUse,
        category: data.category || 'General',
        educationalFact: data.educationalFact,
        timestamp: Date.now(),
      };

      setCurrentResult(newGeneratedItem);
      if (onImageGenerated) {
        onImageGenerated(newGeneratedItem);
      }
    } catch (err: any) {
      console.error('Failed to generate drawing image:', err);
      setError(err.message || 'Could not generate image. Please check your connection or try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = () => {
    if (!currentResult?.imageUrl) return;
    const link = document.createElement('a');
    link.href = currentResult.imageUrl;
    link.download = `chalkboard-ai-${currentResult.subject.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyPrompt = () => {
    if (!currentResult?.imagePrompt) return;
    navigator.clipboard.writeText(currentResult.imagePrompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <div
      id="drawingVisualizerBackdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isLoading) onClose();
      }}
    >
      <div
        id="drawingVisualizerDialog"
        className="bg-[#18232C] border border-[#F5F1E6]/15 rounded-3xl max-w-4xl w-full h-[90vh] max-h-[850px] shadow-2xl flex flex-col text-[#F5F1E6] overflow-hidden relative"
      >
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-[#F5F1E6]/10 flex items-center justify-between bg-[#141C24]/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#E8C468] to-[#E2725B] p-0.5 shadow-lg shadow-[#E8C468]/20">
              <div className="w-full h-full bg-[#18232C] rounded-[14px] flex items-center justify-center text-[#E8C468]">
                <Wand2 className="w-5 h-5 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-hand font-bold text-2xl text-[#E8C468] leading-tight">
                  AI Drawing Visualizer
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#E8C468]/15 border border-[#E8C468]/30 text-[#E8C468] font-bold uppercase tracking-wider">
                  Chalk → Real Image
                </span>
              </div>
              <p className="text-xs text-[#F5F1E6]/60">
                Transform your chalkboard sketch or handwriting into a rich AI-generated visual artwork
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {currentResult && (
              <div className="hidden sm:flex items-center bg-[#1D2B36] p-1 rounded-xl border border-[#F5F1E6]/10 text-xs">
                <button
                  onClick={() => setViewMode('split')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    viewMode === 'split' ? 'bg-[#E8C468] text-[#18232C] font-bold shadow-sm' : 'text-[#F5F1E6]/70 hover:text-white'
                  }`}
                >
                  Side-by-Side
                </button>
                <button
                  onClick={() => setViewMode('ai-only')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    viewMode === 'ai-only' ? 'bg-[#E8C468] text-[#18232C] font-bold shadow-sm' : 'text-[#F5F1E6]/70 hover:text-white'
                  }`}
                >
                  AI Image
                </button>
                <button
                  onClick={() => setViewMode('drawing-only')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    viewMode === 'drawing-only' ? 'bg-[#E8C468] text-[#18232C] font-bold shadow-sm' : 'text-[#F5F1E6]/70 hover:text-white'
                  }`}
                >
                  My Sketch
                </button>
              </div>
            )}

            <button
              id="closeVisualizerBtn"
              onClick={onClose}
              className="p-2 rounded-xl text-[#F5F1E6]/60 hover:text-[#F5F1E6] hover:bg-[#2A3742] transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Main Visual Display Area */}
          {isLoading ? (
            <div className="h-72 sm:h-96 w-full rounded-2xl bg-[#121820] border border-[#F5F1E6]/10 flex flex-col items-center justify-center p-6 text-center space-y-4 shadow-inner relative overflow-hidden">
              {/* Background ambient glow */}
              <div className="absolute -inset-10 bg-gradient-to-r from-[#E8C468]/10 via-[#8FBF8A]/10 to-[#81D4FA]/10 blur-3xl animate-pulse" />

              <div className="relative z-10 flex flex-col items-center space-y-3">
                <div className="w-16 h-16 rounded-3xl bg-[#E8C468]/20 border border-[#E8C468]/40 flex items-center justify-center text-[#E8C468] shadow-xl animate-bounce">
                  <Sparkles className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <h3 className="font-hand font-bold text-2xl text-[#E8C468]">
                    Transforming Your Chalkboard Drawing...
                  </h3>
                  <p className="text-xs text-[#F5F1E6]/70 font-mono">
                    {loadingStep === 1 && '1/3 • Analyzing chalk strokes, contours & drawing geometry...'}
                    {loadingStep === 2 && '2/3 • Interpreting visual subject and composition details...'}
                    {loadingStep === 3 && '3/3 • Rendering high-resolution artwork in selected style...'}
                  </p>
                </div>

                {/* Progress bar */}
                <div className="w-64 h-2 bg-[#1C2732] rounded-full overflow-hidden border border-[#F5F1E6]/10 mt-2">
                  <div 
                    className="h-full bg-gradient-to-r from-[#E8C468] to-[#81D4FA] transition-all duration-700 ease-out rounded-full"
                    style={{ width: `${(loadingStep / 3) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ) : error ? (
            <div className="p-6 rounded-2xl bg-red-950/30 border border-red-500/30 text-center space-y-3">
              <div className="text-red-400 font-bold text-sm">Failed to generate image</div>
              <p className="text-xs text-[#F5F1E6]/70 max-w-md mx-auto">{error}</p>
              <button
                onClick={() => handleGenerate()}
                className="px-4 py-2 rounded-xl bg-[#E8C468] text-[#18232C] text-xs font-bold shadow hover:bg-[#f0d182] inline-flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Generation</span>
              </button>
            </div>
          ) : currentResult ? (
            <div className="space-y-5">
              {/* Subject Banner & Category */}
              <div className="p-4 rounded-2xl bg-[#141C24] border border-[#F5F1E6]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-lg bg-[#8FBF8A]/20 text-[#8FBF8A] border border-[#8FBF8A]/30 text-[11px] font-bold">
                      {currentResult.category}
                    </span>
                    <span className="text-xs text-[#F5F1E6]/50">
                      Style: <strong className="text-[#E8C468] capitalize">{STYLE_OPTIONS.find(s => s.id === currentResult.style)?.label || currentResult.style}</strong>
                    </span>
                  </div>
                  <h3 className="font-hand font-bold text-2xl text-[#E8C468] tracking-wide">
                    {currentResult.subject}
                  </h3>
                  <p className="text-xs text-[#F5F1E6]/70 line-clamp-2">
                    {currentResult.detailedDescription}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                  {currentResult.imageUrl && (
                    <button
                      id="downloadGeneratedImgBtn"
                      onClick={handleDownload}
                      className="px-3.5 py-2 rounded-xl bg-[#2A3742] hover:bg-[#344452] text-[#F5F1E6] text-xs font-medium border border-[#F5F1E6]/15 flex items-center gap-1.5 transition-colors shadow-sm"
                      title="Download PNG image"
                    >
                      <Download className="w-4 h-4 text-[#E8C468]" />
                      <span>Download</span>
                    </button>
                  )}
                  <button
                    id="regenerateImgBtn"
                    onClick={() => handleGenerate()}
                    className="px-3.5 py-2 rounded-xl bg-[#E8C468] hover:bg-[#f0d182] text-[#18232C] text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Re-generate</span>
                  </button>
                </div>
              </div>

              {/* Visual Showcase (Chalk sketch vs Generated Image) */}
              <div className={`grid gap-4 ${viewMode === 'split' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
                {/* Chalkboard Drawing Source */}
                {(viewMode === 'split' || viewMode === 'drawing-only') && (
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-[#F5F1E6]/60 px-1">
                      <span className="flex items-center gap-1.5">
                        <Palette className="w-3.5 h-3.5 text-[#E8C468]" />
                        Your Chalkboard Drawing
                      </span>
                      <span className="text-[10px] text-[#F5F1E6]/40 font-mono">Slate Input</span>
                    </div>

                    <div className="h-64 sm:h-80 rounded-2xl border border-[#F5F1E6]/15 bg-[#121A15] p-2 flex items-center justify-center shadow-inner overflow-hidden relative group">
                      {canvasSnapshot ? (
                        <img
                          src={canvasSnapshot}
                          alt="Student Chalkboard Drawing"
                          className="max-h-full max-w-full object-contain rounded-xl shadow-md"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <span className="text-xs text-[#F5F1E6]/40">No canvas snapshot</span>
                      )}
                    </div>
                  </div>
                )}

                {/* AI Generated Real Image */}
                {(viewMode === 'split' || viewMode === 'ai-only') && (
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-[#E8C468] px-1">
                      <span className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-[#E8C468]" />
                        AI Visual Artwork
                      </span>
                      <span className="text-[10px] text-[#E8C468]/70 font-mono">Generated Output</span>
                    </div>

                    <div className="h-64 sm:h-80 rounded-2xl border border-[#E8C468]/30 bg-[#121820] p-2 flex items-center justify-center shadow-2xl overflow-hidden relative group">
                      {currentResult.imageUrl ? (
                        <img
                          src={currentResult.imageUrl}
                          alt={currentResult.subject}
                          className="max-h-full max-w-full object-contain rounded-xl shadow-2xl transition-transform duration-300 group-hover:scale-[1.02]"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="text-center p-6 space-y-2">
                          <ImageIcon className="w-10 h-10 text-[#E8C468]/40 mx-auto" />
                          <p className="text-xs text-[#F5F1E6]/60">
                            Image generated based on prompt: <br />
                            <span className="text-[#E8C468] italic font-serif">"{currentResult.subject}"</span>
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Educational Fact Callout */}
              {currentResult.educationalFact && (
                <div className="p-3.5 rounded-2xl bg-[#E8C468]/10 border border-[#E8C468]/25 flex items-start gap-3 text-xs text-[#F5F1E6]">
                  <div className="w-7 h-7 rounded-xl bg-[#E8C468]/20 flex items-center justify-center text-[#E8C468] shrink-0 mt-0.5">
                    <Lightbulb className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-[#E8C468] block mb-0.5">Educational Insight:</strong>
                    <span className="text-[#F5F1E6]/85">{currentResult.educationalFact}</span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 space-y-3 text-[#F5F1E6]/60">
              <Sparkles className="w-12 h-12 text-[#E8C468] mx-auto" />
              <p>Ready to transform your chalkboard drawing into an AI masterpiece.</p>
              <button
                onClick={() => handleGenerate()}
                className="px-5 py-2.5 rounded-xl bg-[#E8C468] text-[#18232C] font-bold text-xs shadow"
              >
                Generate Image Now
              </button>
            </div>
          )}

          {/* Style Controls & Prompt Customizer */}
          <div className="space-y-4 pt-4 border-t border-[#F5F1E6]/10">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-[#E8C468] flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" />
                Select Artistic Style
              </label>
              <span className="text-[11px] text-[#F5F1E6]/50">
                Click any style to regenerate with that visual treatment
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {STYLE_OPTIONS.map((opt) => {
                const isSelected = selectedStyle === opt.id;
                return (
                  <button
                    key={opt.id}
                    id={`styleBtn-${opt.id}`}
                    onClick={() => {
                      setSelectedStyle(opt.id);
                      handleGenerate(opt.id);
                    }}
                    className={`p-2.5 rounded-2xl border text-left flex flex-col items-center gap-1 transition-all text-center ${
                      isSelected
                        ? 'bg-[#2A3742] border-[#E8C468] text-[#E8C468] shadow-md scale-105'
                        : 'bg-[#141C24] border-[#F5F1E6]/10 text-[#F5F1E6]/70 hover:bg-[#1C2732] hover:border-[#F5F1E6]/25'
                    }`}
                    title={opt.desc}
                  >
                    <span className="text-xl">{opt.icon}</span>
                    <span className="text-xs font-bold truncate max-w-full">{opt.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Custom refinement prompt input */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-[#F5F1E6]/70 flex items-center justify-between">
                <span>Refine or Add Details (Optional):</span>
                {currentResult?.imagePrompt && (
                  <button
                    onClick={handleCopyPrompt}
                    className="text-[10px] text-[#E8C468] hover:underline flex items-center gap-1"
                  >
                    {copiedPrompt ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedPrompt ? 'Copied Prompt!' : 'Copy AI Prompt'}</span>
                  </button>
                )}
              </label>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  placeholder="e.g. 'Add a sunset sky', 'Make it underwater with coral', 'Turn it into a blueprint diagram'..."
                  className="flex-1 bg-[#121820] border border-[#F5F1E6]/15 rounded-xl px-3.5 py-2 text-xs text-[#F5F1E6] focus:outline-none focus:border-[#E8C468] placeholder:text-[#F5F1E6]/30"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !isLoading) {
                      handleGenerate();
                    }
                  }}
                />
                <button
                  onClick={() => handleGenerate()}
                  disabled={isLoading}
                  className="px-4 py-2 rounded-xl bg-[#E8C468] hover:bg-[#f0d182] disabled:opacity-50 text-[#18232C] text-xs font-bold flex items-center gap-1.5 shadow transition-all shrink-0"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Update</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#F5F1E6]/10 bg-[#141C24] flex items-center justify-between shrink-0 text-xs text-[#F5F1E6]/60">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#8FBF8A] animate-ping" />
            <span>Powered by Gemini Multimodal Vision & Image Generation</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#2A3742] hover:bg-[#344452] text-[#F5F1E6] font-semibold text-xs border border-[#F5F1E6]/15 transition-colors"
          >
            Back to Blackboard
          </button>
        </div>
      </div>
    </div>
  );
}
