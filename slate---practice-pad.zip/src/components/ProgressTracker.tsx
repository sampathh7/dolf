import React, { useState } from 'react';
import { FeedbackHistoryItem } from '../types';
import { 
  Award, 
  TrendingUp, 
  CheckCircle2, 
  Calendar, 
  Trash2, 
  X, 
  BarChart3,
  ChevronDown
} from 'lucide-react';

interface ProgressTrackerProps {
  history: FeedbackHistoryItem[];
  onClearHistory: () => void;
}

export default function ProgressTracker({ history, onClearHistory }: ProgressTrackerProps) {
  const [isOpen, setIsOpen] = useState(false);

  const totalDrills = history.length;
  const averageScore = totalDrills > 0
    ? Math.round(history.reduce((sum, item) => sum + item.score, 0) / totalDrills)
    : 0;

  const highestScore = totalDrills > 0
    ? Math.max(...history.map((item) => item.score))
    : 0;

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-[#8FBF8A]';
    if (score >= 60) return 'text-[#E8C468]';
    return 'text-[#E2725B]';
  };

  const getScoreBg = (score: number) => {
    if (score >= 85) return 'bg-[#8FBF8A]/15 border-[#8FBF8A]/30 text-[#8FBF8A]';
    if (score >= 60) return 'bg-[#E8C468]/15 border-[#E8C468]/30 text-[#E8C468]';
    return 'bg-[#E2725B]/15 border-[#E2725B]/30 text-[#E2725B]';
  };

  return (
    <div className="relative">
      {/* Trigger Button / Badge in Toolbar */}
      <button
        id="progressTrackerBtn"
        onClick={() => setIsOpen(!isOpen)}
        className="px-3 py-1.5 rounded-xl bg-[#213A30] hover:bg-[#2A473B] text-[#F5F1E6] border border-[#F5F1E6]/15 text-xs font-medium flex items-center gap-2 transition-all hover:border-[#E8C468]/40"
        title="View Overall Practice Progress & Average Score"
      >
        <div className="flex items-center gap-1.5">
          <Award className="w-4 h-4 text-[#E8C468]" />
          <span className="text-[#F5F1E6]/70 hidden sm:inline">Avg:</span>
          <span className={`font-mono-code font-bold ${totalDrills > 0 ? getScoreColor(averageScore) : 'text-[#F5F1E6]/40'}`}>
            {totalDrills > 0 ? `${averageScore}%` : '—'}
          </span>
        </div>

        {totalDrills > 0 && (
          <span className="hidden md:inline text-[10px] px-1.5 py-0.5 rounded-md bg-[#182821] text-[#F5F1E6]/60">
            {totalDrills} {totalDrills === 1 ? 'drill' : 'drills'}
          </span>
        )}
        <ChevronDown className={`w-3.5 h-3.5 text-[#F5F1E6]/40 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Popover Card */}
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-30" 
            onClick={() => setIsOpen(false)} 
          />
          <div 
            id="progressTrackerPopup"
            className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-[#1C2B24] border border-[#F5F1E6]/15 rounded-2xl shadow-2xl p-4 z-40 animate-in fade-in zoom-in-95 duration-150 flex flex-col gap-3.5"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#F5F1E6]/10 pb-2.5">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-[#E8C468]" />
                <h3 className="font-hand text-xl font-bold text-[#E8C468] tracking-wide">
                  Practice Progress
                </h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-[#F5F1E6]/50 hover:text-[#F5F1E6] hover:bg-[#213A30] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Score Overview Stats */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-[#213A30] p-2.5 rounded-xl border border-[#F5F1E6]/10">
                <div className="text-[10px] font-medium uppercase tracking-wider text-[#F5F1E6]/50">
                  Overall Avg
                </div>
                <div className={`text-xl font-bold font-mono-code mt-0.5 ${totalDrills > 0 ? getScoreColor(averageScore) : 'text-[#F5F1E6]/40'}`}>
                  {totalDrills > 0 ? `${averageScore}%` : '—'}
                </div>
              </div>

              <div className="bg-[#213A30] p-2.5 rounded-xl border border-[#F5F1E6]/10">
                <div className="text-[10px] font-medium uppercase tracking-wider text-[#F5F1E6]/50">
                  Completed
                </div>
                <div className="text-xl font-bold font-mono-code text-[#F5F1E6] mt-0.5">
                  {totalDrills}
                </div>
              </div>

              <div className="bg-[#213A30] p-2.5 rounded-xl border border-[#F5F1E6]/10">
                <div className="text-[10px] font-medium uppercase tracking-wider text-[#F5F1E6]/50">
                  Best Score
                </div>
                <div className={`text-xl font-bold font-mono-code mt-0.5 ${totalDrills > 0 ? getScoreColor(highestScore) : 'text-[#F5F1E6]/40'}`}>
                  {totalDrills > 0 ? `${highestScore}%` : '—'}
                </div>
              </div>
            </div>

            {/* Visual Progress Bar */}
            {totalDrills > 0 && (
              <div className="bg-[#182821] p-3 rounded-xl border border-[#F5F1E6]/10 space-y-1.5">
                <div className="flex justify-between text-[11px] font-medium text-[#F5F1E6]/70">
                  <span>Proficiency Rating</span>
                  <span className={getScoreColor(averageScore)}>{averageScore}/100</span>
                </div>
                <div className="w-full bg-[#213A30] h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      averageScore >= 85 ? 'bg-[#8FBF8A]' : averageScore >= 60 ? 'bg-[#E8C468]' : 'bg-[#E2725B]'
                    }`}
                    style={{ width: `${Math.max(4, Math.min(100, averageScore))}%` }}
                  />
                </div>
              </div>
            )}

            {/* History List */}
            <div>
              <div className="flex items-center justify-between text-[11px] font-medium uppercase tracking-wider text-[#F5F1E6]/50 mb-2">
                <span>Recent Drill Results</span>
                {totalDrills > 0 && (
                  <button
                    onClick={onClearHistory}
                    className="flex items-center gap-1 text-[#E2725B]/70 hover:text-[#E2725B] transition-colors"
                    title="Clear history logs"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                )}
              </div>

              {totalDrills === 0 ? (
                <div className="py-6 text-center text-xs text-[#F5F1E6]/50 bg-[#182821] rounded-xl border border-[#F5F1E6]/10">
                  No feedback results recorded yet.
                  <div className="text-[11px] text-[#F5F1E6]/40 mt-1">
                    Write on the slate and tap "Check My Work" to start tracking.
                  </div>
                </div>
              ) : (
                <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                  {history.slice().reverse().map((item) => (
                    <div
                      key={item.id}
                      className="bg-[#213A30] p-2.5 rounded-xl border border-[#F5F1E6]/10 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium text-[#F5F1E6] truncate">
                          {item.topic || 'Practice Drill'}
                        </div>
                        {item.question && (
                          <div className="text-[11px] text-[#F5F1E6]/50 truncate">
                            {item.question}
                          </div>
                        )}
                        <div className="text-[10px] text-[#F5F1E6]/40 mt-0.5">
                          {new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {item.mistakesCount === 0 ? '0 mistakes' : `${item.mistakesCount} error(s)`}
                        </div>
                      </div>

                      <div className={`px-2.5 py-1 rounded-lg border text-xs font-bold font-mono-code shrink-0 ${getScoreBg(item.score)}`}>
                        {item.score}%
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
