import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Stroke, StrokePoint, ChalkColorOption, BoardThemeOption, FeedbackResult } from '../types';
import { AiDrawingState } from '../utils/aiDrawingRunner';
import { 
  Pen, 
  Eraser, 
  RotateCcw, 
  RotateCw, 
  Trash2, 
  Download, 
  Sparkles, 
  Palette, 
  Minus, 
  Radio, 
  Volume2, 
  VolumeX, 
  Grid, 
  Maximize2, 
  Wand2, 
  Pencil, 
  Pause, 
  Play, 
  FastForward, 
  XCircle, 
  CheckCircle2,
  Smile
} from 'lucide-react';
import { chalkAudio } from '../utils/chalkAudio';
import { BOARD_THEMES, CHALK_COLORS } from '../utils/themes';
import SlateCartoonHeroFeedback, { CartoonHeroId } from './SlateCartoonHeroFeedback';

export { CHALK_COLORS };

interface ChalkCanvasProps {
  strokes: Stroke[];
  setStrokes: React.Dispatch<React.SetStateAction<Stroke[]>>;
  onSubmitWork: (canvasImageBase64: string) => void;
  isChecking: boolean;
  activeColor: string;
  setActiveColor: (hex: string) => void;
  strokeWidth: number;
  setStrokeWidth: (w: number) => void;
  mode: 'pen' | 'erase';
  setMode: (m: 'pen' | 'erase') => void;
  boardTheme?: BoardThemeOption;
  onOpenColorSettings?: () => void;
  onOpenDrawingVisualizer?: () => void;
  onOpenAutoDraw?: () => void;
  aiDrawingState?: AiDrawingState;
  onPauseAiDrawing?: () => void;
  onResumeAiDrawing?: () => void;
  onSkipAiDrawing?: () => void;
  onCancelAiDrawing?: () => void;
  getCanvasSnapshotRef?: React.MutableRefObject<(() => string | null) | null>;
  onOpenLiveVoice?: () => void;
  feedback?: FeedbackResult | null;
  topic?: string;
  question?: string;
  isCartoonFeedbackVisible?: boolean;
  onCloseCartoonFeedback?: () => void;
  onOpenCartoonFeedback?: () => void;
  onOpenDetailedCorrections?: () => void;
}

export default function ChalkCanvas({
  strokes,
  setStrokes,
  onSubmitWork,
  isChecking,
  activeColor,
  setActiveColor,
  strokeWidth,
  setStrokeWidth,
  mode,
  setMode,
  boardTheme = BOARD_THEMES[0],
  onOpenColorSettings,
  onOpenDrawingVisualizer,
  onOpenAutoDraw,
  aiDrawingState,
  onPauseAiDrawing,
  onResumeAiDrawing,
  onSkipAiDrawing,
  onCancelAiDrawing,
  getCanvasSnapshotRef,
  onOpenLiveVoice,
}: ChalkCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const bgCanvasRef = useRef<HTMLCanvasElement>(null);
  const drawCanvasRef = useRef<HTMLCanvasElement>(null);

  const [redoStack, setRedoStack] = useState<Stroke[]>([]);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [isSoundOn, setIsSoundOn] = useState<boolean>(() => chalkAudio.getSoundEnabled());
  const [showGrid, setShowGrid] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('slate_grid_pattern_enabled');
      return saved === 'true';
    } catch {
      return false;
    }
  });

  // Active stroke being drawn
  const activeStrokeRef = useRef<Stroke | null>(null);
  const isPointerDownRef = useRef(false);

  // Redraw background chalkboard grid/lines using active boardTheme
  const drawChalkboardBackground = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.clearRect(0, 0, width, height);

    // Deep chalkboard gradient according to chosen theme
    const [c1, c2, c3] = boardTheme.gradient;
    const bgGrad = ctx.createLinearGradient(0, 0, width, height);
    bgGrad.addColorStop(0, c1);
    bgGrad.addColorStop(0.5, c2);
    bgGrad.addColorStop(1, c3);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Subtle chalk dust specks
    ctx.fillStyle = `rgba(245, 241, 230, ${boardTheme.dustAlpha || 0.018})`;
    for (let i = 0; i < 420; i++) {
      const rx = (Math.sin(i * 997) * 0.5 + 0.5) * width;
      const ry = (Math.cos(i * 613) * 0.5 + 0.5) * height;
      ctx.fillRect(rx, ry, (i % 3) + 1, (i % 2) + 1);
    }

    if (showGrid) {
      // Faint square alignment grid pattern (36px grid)
      const gridSize = 36;
      ctx.lineWidth = 1;

      // Vertical grid lines
      for (let x = gridSize; x < width; x += gridSize) {
        const isMajor = Math.round(x / gridSize) % 4 === 0;
        ctx.strokeStyle = isMajor ? boardTheme.gridMajorColor : boardTheme.gridLineColor;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      // Horizontal grid lines
      for (let y = gridSize; y < height; y += gridSize) {
        const isMajor = Math.round(y / gridSize) % 4 === 0;
        ctx.strokeStyle = isMajor ? boardTheme.gridMajorColor : boardTheme.gridLineColor;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Faint intersection dots for handwriting and coordinate guidance
      ctx.fillStyle = boardTheme.accentColor ? `${boardTheme.accentColor}33` : 'rgba(232, 196, 104, 0.18)';
      for (let x = gridSize; x < width; x += gridSize * 2) {
        for (let y = gridSize; y < height; y += gridSize * 2) {
          ctx.fillRect(x - 1, y - 1, 2, 2);
        }
      }
    } else {
      // Ruled lines (horizontal notebook style)
      ctx.strokeStyle = boardTheme.ruledLineColor;
      ctx.lineWidth = 1;
      const lineHeight = 44;
      for (let y = lineHeight + 20; y < height; y += lineHeight) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    }

    // Left vertical margin line
    ctx.strokeStyle = boardTheme.marginColor;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(64, 0);
    ctx.lineTo(64, height);
    ctx.stroke();
  }, [showGrid, boardTheme]);

  // Render a stroke on canvas
  const renderSingleStroke = (ctx: CanvasRenderingContext2D, stroke: Stroke | null | undefined) => {
    if (!stroke || !stroke.points || !Array.isArray(stroke.points) || stroke.points.length === 0) return;

    ctx.save();
    if (stroke.type === 'erase') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.fillStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = stroke.color || '#F5F1E6';
      ctx.fillStyle = stroke.color || '#F5F1E6';
      // Slight chalk grain glow
      ctx.shadowColor = stroke.color || '#F5F1E6';
      ctx.shadowBlur = 1;
    }

    ctx.lineWidth = stroke.width || 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (stroke.points.length === 1) {
      const p = stroke.points[0];
      if (p) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, (stroke.width || 4) / 2, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      const p0 = stroke.points[0];
      if (!p0) {
        ctx.restore();
        return;
      }
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);

      for (let i = 1; i < stroke.points.length - 1; i++) {
        const p1 = stroke.points[i];
        const p2 = stroke.points[i + 1];
        if (p1 && p2) {
          const midX = (p1.x + p2.x) / 2;
          const midY = (p1.y + p2.y) / 2;
          ctx.quadraticCurveTo(p1.x, p1.y, midX, midY);
        }
      }

      const last = stroke.points[stroke.points.length - 1];
      if (last) {
        ctx.lineTo(last.x, last.y);
        ctx.stroke();
      }
    }
    ctx.restore();
  };

  // Replay all strokes on draw canvas
  const redrawCanvas = useCallback(() => {
    const drawCanvas = drawCanvasRef.current;
    if (!drawCanvas) return;
    const ctx = drawCanvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
    (strokes || []).forEach((stroke) => {
      if (stroke) {
        renderSingleStroke(ctx, stroke);
      }
    });
  }, [strokes]);

  // Handle Resize & DPI
  const handleResize = useCallback(() => {
    const container = containerRef.current;
    const bgCanvas = bgCanvasRef.current;
    const drawCanvas = drawCanvasRef.current;
    if (!container || !bgCanvas || !drawCanvas) return;

    const rect = container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;

    const width = Math.floor(rect.width);
    const height = Math.floor(rect.height);

    if (width <= 0 || height <= 0) return;

    [bgCanvas, drawCanvas].forEach((c) => {
      c.width = width * dpr;
      c.height = height * dpr;
      c.style.width = `${width}px`;
      c.style.height = `${height}px`;
      const ctx = c.getContext('2d');
      if (ctx) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
    });

    const bgCtx = bgCanvas.getContext('2d');
    if (bgCtx) {
      drawChalkboardBackground(bgCtx, width, height);
    }
    redrawCanvas();
  }, [drawChalkboardBackground, redrawCanvas]);

  useEffect(() => {
    handleResize();
    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }
    window.addEventListener('resize', handleResize);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleResize);
    };
  }, [handleResize]);

  useEffect(() => {
    redrawCanvas();
    setHasDrawn(strokes.length > 0);
  }, [strokes, redrawCanvas]);

  // Pointer drawing handlers
  const getCanvasPoint = (e: React.PointerEvent<HTMLCanvasElement>): StrokePoint => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const pressure = e.pressure && e.pressure > 0 ? e.pressure : 0.5;
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      pressure,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {
      // ignore
    }

    isPointerDownRef.current = true;
    const pt = getCanvasPoint(e);

    // Play tactile chalk contact tap & start continuous sound
    chalkAudio.startStrokeSound(mode, pt.x, pt.y);

    const actualWidth = mode === 'erase' ? 32 : Math.max(2, strokeWidth * (0.6 + (pt.pressure || 0.5) * 0.8));

    const newStroke: Stroke = {
      id: `stroke-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      type: mode,
      points: [pt],
      color: mode === 'erase' ? '#000000' : activeColor,
      width: actualWidth,
    };

    activeStrokeRef.current = newStroke;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      renderSingleStroke(ctx, newStroke);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isPointerDownRef.current || !activeStrokeRef.current || !Array.isArray(activeStrokeRef.current.points)) return;
    e.preventDefault();
    const pt = getCanvasPoint(e);
    const stroke = activeStrokeRef.current;
    if (!stroke || !stroke.points) return;
    stroke.points.push(pt);

    // Modulate chalk friction audio with drawing velocity & pressure
    chalkAudio.updateStrokeSound(pt.x, pt.y, pt.pressure, mode);

    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw the latest segment
    ctx.save();
    if (stroke.type === 'erase') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = stroke.color || '#F5F1E6';
      ctx.shadowColor = stroke.color || '#F5F1E6';
      ctx.shadowBlur = 1;
    }

    ctx.lineWidth = stroke.width || 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const pts = stroke.points;
    const n = pts.length;
    if (n >= 2 && pts[n - 2] && pts[n - 1]) {
      ctx.beginPath();
      ctx.moveTo(pts[n - 2].x, pts[n - 2].y);
      ctx.lineTo(pts[n - 1].x, pts[n - 1].y);
      ctx.stroke();
    }
    ctx.restore();
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    chalkAudio.stopStrokeSound();
    if (!isPointerDownRef.current) return;
    isPointerDownRef.current = false;

    const stroke = activeStrokeRef.current;
    if (stroke && Array.isArray(stroke.points) && stroke.points.length > 0) {
      setStrokes((prev) => [...(prev || []).filter(Boolean), stroke]);
      setRedoStack([]);
    }
    activeStrokeRef.current = null;

    try {
      if (drawCanvasRef.current?.hasPointerCapture(e.pointerId)) {
        drawCanvasRef.current.releasePointerCapture(e.pointerId);
      }
    } catch {
      // ignore
    }
  };

  const handleUndo = () => {
    if (!strokes || strokes.length === 0) return;
    const validStrokes = strokes.filter(Boolean);
    if (validStrokes.length === 0) return;
    const lastStroke = validStrokes[validStrokes.length - 1];
    setRedoStack((prev) => [...(prev || []).filter(Boolean), lastStroke]);
    setStrokes(validStrokes.slice(0, -1));
  };

  const handleRedo = () => {
    if (!redoStack || redoStack.length === 0) return;
    const validRedos = redoStack.filter(Boolean);
    if (validRedos.length === 0) return;
    const nextStroke = validRedos[validRedos.length - 1];
    setRedoStack(validRedos.slice(0, -1));
    setStrokes((prev) => [...(prev || []).filter(Boolean), nextStroke]);
  };

  const handleClear = () => {
    if (strokes.length === 0) return;
    setStrokes([]);
    setRedoStack([]);
    setShowClearConfirm(false);
  };

  // Export board as merged PNG base64
  const getMergedCanvasBase64 = (): string => {
    const bg = bgCanvasRef.current;
    const draw = drawCanvasRef.current;
    if (!bg || !draw) return '';

    const offCanvas = document.createElement('canvas');
    offCanvas.width = bg.width;
    offCanvas.height = bg.height;
    const offCtx = offCanvas.getContext('2d');
    if (!offCtx) return '';

    // Draw background then strokes
    offCtx.drawImage(bg, 0, 0);
    offCtx.drawImage(draw, 0, 0);

    return offCanvas.toDataURL('image/png');
  };

  if (getCanvasSnapshotRef) {
    getCanvasSnapshotRef.current = getMergedCanvasBase64;
  }

  const handleCheckWork = () => {
    if (strokes.length === 0) return;
    const dataUrl = getMergedCanvasBase64();
    if (dataUrl) {
      onSubmitWork(dataUrl);
    }
  };

  const handleDownloadSnapshot = () => {
    const dataUrl = getMergedCanvasBase64();
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `slate-practice-${new Date().toISOString().slice(0, 10)}.png`;
    a.click();
  };

  return (
    <div className="relative flex-1 h-full w-full bg-[#182821] overflow-hidden select-none flex flex-col">
      {/* Board Container */}
      <div id="boardWrap" ref={containerRef} className="relative flex-1 w-full h-full cursor-crosshair">
        <canvas
          id="bgCanvas"
          ref={bgCanvasRef}
          className="absolute inset-0 pointer-events-none"
        />
        <canvas
          id="drawCanvas"
          ref={drawCanvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="absolute inset-0 touch-none"
        />

        {/* Floating Left Floating Chalk Tools */}
        <div 
          id="chalkToolbar"
          className="absolute left-4 top-4 z-10 flex flex-col gap-2 p-2 bg-[#182821]/90 backdrop-blur-md rounded-2xl border border-[#F5F1E6]/10 shadow-2xl transition-all"
        >
          {/* Pen Toggle */}
          <button
            id="penToolBtn"
            onClick={() => setMode('pen')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              mode === 'pen'
                ? 'bg-[#E8C468] text-[#182821] shadow-lg shadow-[#E8C468]/20 font-semibold'
                : 'text-[#F5F1E6]/70 hover:text-[#F5F1E6] hover:bg-[#213A30]'
            }`}
            title="Chalk Pen"
          >
            <Pen className="w-5 h-5" />
          </button>

          {/* Eraser Toggle */}
          <button
            id="eraserToolBtn"
            onClick={() => setMode('erase')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              mode === 'erase'
                ? 'bg-[#E2725B] text-[#182821] shadow-lg shadow-[#E2725B]/20 font-semibold'
                : 'text-[#F5F1E6]/70 hover:text-[#F5F1E6] hover:bg-[#213A30]'
            }`}
            title="Chalk Duster Eraser"
          >
            <Eraser className="w-5 h-5" />
          </button>

          {/* Chalk Color Palette Dropdown */}
          <div className="relative">
            <button
              id="colorPickerBtn"
              onClick={() => setShowColorPicker(!showColorPicker)}
              className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#F5F1E6]/70 hover:text-[#F5F1E6] hover:bg-[#213A30]"
              title="Chalk Colors"
            >
              <div 
                className="w-5 h-5 rounded-full border-2 border-white/40 shadow-inner" 
                style={{ backgroundColor: activeColor }}
              />
            </button>

            {showColorPicker && (
              <div 
                id="colorPickerPopup"
                className="absolute left-12 top-0 bg-[#1C2B24] border border-[#F5F1E6]/15 p-3 rounded-2xl shadow-2xl flex flex-col gap-2.5 w-52 z-30 animate-in fade-in zoom-in-95 duration-150"
              >
                <div className="flex items-center justify-between px-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8C468]">
                    Chalk Palette
                  </span>
                  <span className="text-[10px] text-[#F5F1E6]/50">
                    {CHALK_COLORS.find((c) => c.hex === activeColor)?.name.split(' ')[0] || ''}
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-1.5">
                  {CHALK_COLORS.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        setActiveColor(c.hex);
                        setMode('pen');
                        setShowColorPicker(false);
                      }}
                      className={`h-8 w-full rounded-lg flex items-center justify-center transition-transform hover:scale-110 ${
                        activeColor === c.hex && mode === 'pen'
                          ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1C2B24]'
                          : ''
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    />
                  ))}
                </div>

                <div className="pt-2 border-t border-[#F5F1E6]/10">
                  <div className="text-[11px] font-medium uppercase tracking-wider text-[#F5F1E6]/50 px-1 mb-1">
                    Stroke Width: {strokeWidth}px
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={12}
                    step={1}
                    value={strokeWidth}
                    onChange={(e) => setStrokeWidth(Number(e.target.value))}
                    className="w-full accent-[#E8C468] cursor-pointer"
                  />
                </div>

                {onOpenColorSettings && (
                  <button
                    onClick={() => {
                      setShowColorPicker(false);
                      onOpenColorSettings();
                    }}
                    className="mt-1 w-full py-1.5 px-2 rounded-xl bg-[#213A30] hover:bg-[#2A473B] text-[11px] font-semibold text-[#E8C468] border border-[#E8C468]/30 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Palette className="w-3.5 h-3.5" />
                    <span>Board & Color Settings</span>
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="h-px bg-[#F5F1E6]/10 my-0.5" />

          {/* Color & Theme Settings Button */}
          {onOpenColorSettings && (
            <button
              id="openCanvasColorSettingsBtn"
              onClick={onOpenColorSettings}
              className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#E8C468]/80 hover:text-[#E8C468] hover:bg-[#213A30]"
              title="Board & Chalk Color Settings"
            >
              <Palette className="w-4 h-4" />
            </button>
          )}

          {/* Undo */}
          <button
            id="undoBtn"
            onClick={handleUndo}
            disabled={strokes.length === 0}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#F5F1E6]/70 hover:text-[#F5F1E6] hover:bg-[#213A30] disabled:opacity-30 disabled:pointer-events-none"
            title="Undo"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Redo */}
          <button
            id="redoBtn"
            onClick={handleRedo}
            disabled={redoStack.length === 0}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#F5F1E6]/70 hover:text-[#F5F1E6] hover:bg-[#213A30] disabled:opacity-30 disabled:pointer-events-none"
            title="Redo"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Clear Board */}
          <button
            id="clearBoardBtn"
            onClick={() => {
              if (strokes.length > 0) setShowClearConfirm(true);
            }}
            disabled={strokes.length === 0}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#F5F1E6]/70 hover:text-[#E2725B] hover:bg-[#213A30] disabled:opacity-30 disabled:pointer-events-none"
            title="Clear Board"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          {/* AI Auto-Draw on Slate */}
          {onOpenAutoDraw && (
            <button
              id="toolbarAutoDrawBtn"
              onClick={onOpenAutoDraw}
              disabled={aiDrawingState?.isDrawing}
              className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#81D4FA] hover:bg-[#213A30] hover:scale-105 disabled:opacity-30 disabled:pointer-events-none"
              title="Order AI to Draw on Slate"
            >
              <Pencil className="w-4 h-4 text-[#81D4FA]" />
            </button>
          )}

          {/* Transform into AI Image */}
          {onOpenDrawingVisualizer && (
            <button
              id="toolbarVisualizerBtn"
              onClick={onOpenDrawingVisualizer}
              disabled={strokes.length === 0 || aiDrawingState?.isDrawing}
              className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#E8C468] hover:bg-[#213A30] hover:scale-105 disabled:opacity-30 disabled:pointer-events-none"
              title="Transform Drawing into AI Image"
            >
              <Wand2 className="w-4 h-4" />
            </button>
          )}

          {/* Download Snapshot */}
          <button
            id="downloadSnapshotBtn"
            onClick={handleDownloadSnapshot}
            disabled={strokes.length === 0 || aiDrawingState?.isDrawing}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all text-[#F5F1E6]/70 hover:text-[#F5F1E6] hover:bg-[#213A30] disabled:opacity-30 disabled:pointer-events-none"
            title="Save Board as Image"
          >
            <Download className="w-4 h-4" />
          </button>

          <div className="h-px bg-[#F5F1E6]/10 my-0.5" />

          {/* Alignment Grid Pattern Toggle */}
          <button
            id="toggleGridBtn"
            onClick={() => {
              setShowGrid((prev) => {
                const next = !prev;
                try {
                  localStorage.setItem('slate_grid_pattern_enabled', String(next));
                } catch {}
                return next;
              });
            }}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              showGrid
                ? 'bg-[#E8C468]/20 text-[#E8C468] border border-[#E8C468]/40 shadow-sm'
                : 'text-[#F5F1E6]/50 hover:text-[#F5F1E6] hover:bg-[#213A30]'
            }`}
            title={showGrid ? 'Alignment Grid: ON (Click for classic notebook lines)' : 'Alignment Grid: OFF (Click to display alignment grid)'}
          >
            <Grid className="w-4 h-4" />
          </button>

          {/* Chalk Sound FX Toggle */}
          <button
            id="toggleChalkSoundBtn"
            onClick={() => {
              const newState = chalkAudio.toggleSound();
              setIsSoundOn(newState);
            }}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              isSoundOn
                ? 'text-[#8FBF8A] hover:bg-[#213A30]'
                : 'text-[#F5F1E6]/40 hover:text-[#F5F1E6]/70 hover:bg-[#213A30]'
            }`}
            title={isSoundOn ? 'Chalk Sound Effects: ON (Click to mute)' : 'Chalk Sound Effects: MUTED (Click to enable)'}
          >
            {isSoundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>

        {/* Top-Right "Order AI Draw", "Check My Work" & "AI Visualizer" Action Bar */}
        <div id="submitRow" className="absolute right-4 top-4 z-10 flex items-center gap-2.5">
          {onOpenAutoDraw && (
            <button
              id="topBarAutoDrawBtn"
              onClick={onOpenAutoDraw}
              disabled={aiDrawingState?.isDrawing}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-[#81D4FA]/20 to-[#8FBF8A]/20 hover:from-[#81D4FA]/30 hover:to-[#8FBF8A]/30 text-[#81D4FA] border border-[#81D4FA]/40 backdrop-blur-md font-bold text-xs shadow-lg flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none"
              title="Order AI to sketch or draw diagrams on the chalkboard"
            >
              <Pencil className="w-4 h-4 text-[#81D4FA] animate-bounce" />
              <span className="hidden sm:inline">Order AI to Draw</span>
            </button>
          )}

          {onOpenDrawingVisualizer && (
            <button
              id="visualizeDrawingActionBtn"
              onClick={onOpenDrawingVisualizer}
              disabled={strokes.length === 0 || aiDrawingState?.isDrawing}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-[#E8C468]/20 via-[#E8C468]/30 to-[#E2725B]/20 hover:from-[#E8C468]/30 hover:to-[#E2725B]/30 text-[#E8C468] border border-[#E8C468]/40 backdrop-blur-md font-bold text-xs shadow-lg flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none"
              title="Transform your chalk sketch into an AI visual image"
            >
              <Wand2 className="w-4 h-4 text-[#E8C468] animate-pulse" />
              <span className="hidden sm:inline">Turn into Image</span>
            </button>
          )}

          {onOpenLiveVoice && (
            <button
              id="canvasLiveVoiceBtn"
              onClick={onOpenLiveVoice}
              disabled={aiDrawingState?.isDrawing}
              className="px-3.5 py-2.5 rounded-xl bg-[#213A30]/90 hover:bg-[#2A473B] text-[#8FBF8A] border border-[#8FBF8A]/40 backdrop-blur-md font-semibold text-xs shadow-lg flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40"
              title="Talk in real-time with Slate Live Voice Tutor"
            >
              <Radio className="w-4 h-4 animate-pulse text-[#8FBF8A]" />
              <span className="hidden sm:inline">Voice Tutor</span>
            </button>
          )}

          <button
            id="submitWorkBtn"
            onClick={handleCheckWork}
            disabled={strokes.length === 0 || isChecking || aiDrawingState?.isDrawing}
            className="px-5 py-2.5 rounded-xl bg-[#E8C468] hover:bg-[#f0d182] text-[#182821] font-semibold text-sm shadow-xl shadow-[#E8C468]/20 flex items-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:scale-[1.02] active:scale-[0.98]"
          >
            <Sparkles className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
            {isChecking ? 'Checking with Gemini…' : 'Check My Work'}
          </button>
        </div>

        {/* AI Drawing in Progress Floating HUD Header */}
        {aiDrawingState?.isDrawing && (
          <div 
            id="aiDrawingHudBanner"
            className="absolute top-4 left-1/2 -translate-x-1/2 z-20 px-4 py-2.5 rounded-2xl bg-[#14231C]/95 border-2 border-[#81D4FA]/50 shadow-2xl backdrop-blur-md flex items-center gap-3 animate-fadeIn"
          >
            <div className="w-8 h-8 rounded-xl bg-[#81D4FA]/20 border border-[#81D4FA]/40 flex items-center justify-center text-[#81D4FA] shrink-0">
              <Pencil className="w-4 h-4 animate-bounce" />
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#81D4FA] tracking-wide">
                  AI Drawing on Slate:
                </span>
                <span className="text-xs font-hand font-bold text-[#F5F1E6]">
                  {aiDrawingState.title}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-[#81D4FA]/20 text-[#81D4FA] font-mono">
                  {aiDrawingState.currentStrokeIndex}/{aiDrawingState.totalStrokes}
                </span>
              </div>
              <p className="text-[11px] text-[#F5F1E6]/70 truncate max-w-[240px] sm:max-w-xs">
                {aiDrawingState.currentStepDescription}
              </p>
            </div>

            {/* Drawing Controls */}
            <div className="flex items-center gap-1.5 border-l border-[#F5F1E6]/15 pl-2 ml-1">
              {aiDrawingState.isPaused ? (
                <button
                  type="button"
                  onClick={onResumeAiDrawing}
                  className="p-1.5 rounded-lg bg-[#81D4FA] text-[#121F19] hover:bg-[#a0e0fd] transition-all"
                  title="Resume drawing"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onPauseAiDrawing}
                  className="p-1.5 rounded-lg bg-[#213A30] text-[#F5F1E6] hover:bg-[#2C4C3F] transition-all"
                  title="Pause drawing"
                >
                  <Pause className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                type="button"
                onClick={onSkipAiDrawing}
                className="p-1.5 rounded-lg bg-[#213A30] text-[#E8C468] hover:bg-[#2C4C3F] transition-all"
                title="Skip to finished diagram"
              >
                <FastForward className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={onCancelAiDrawing}
                className="p-1.5 rounded-lg bg-[#213A30] text-[#E2725B] hover:bg-[#2C4C3F] transition-all"
                title="Stop drawing"
              >
                <XCircle className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Dynamic Animated Chalk Cursor Tip */}
        {aiDrawingState?.isDrawing && aiDrawingState.activeCoordinates && (
          <div
            className="absolute pointer-events-none z-30 transition-all duration-75 ease-out"
            style={{
              left: `${aiDrawingState.activeCoordinates.x}px`,
              top: `${aiDrawingState.activeCoordinates.y}px`,
              transform: 'translate(-50%, -100%)',
            }}
          >
            {/* Glowing Chalk Stick Visual */}
            <div className="relative flex flex-col items-center">
              <div 
                className="w-4 h-10 rounded-t-sm shadow-xl flex items-end justify-center pb-1 text-[9px] font-bold text-black/60 rotate-12"
                style={{
                  backgroundColor: aiDrawingState.activeColor || '#F5F1E6',
                  boxShadow: `0 0 16px ${aiDrawingState.activeColor || '#F5F1E6'}88`,
                }}
              >
                <span className="font-mono text-[7px] rotate-90 opacity-70">CHALK</span>
              </div>
              {/* Glow particle at contact point */}
              <div 
                className="w-2.5 h-2.5 rounded-full -mt-1 animate-ping"
                style={{ backgroundColor: aiDrawingState.activeColor || '#F5F1E6' }}
              />
            </div>
          </div>
        )}

        {/* Empty Slate Prompt Hint */}
        {!hasDrawn && (
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center text-center p-6 select-none opacity-40 transition-opacity">
            <div className="font-hand text-4xl sm:text-5xl text-[#F5F1E6] mb-2 tracking-wide">
              Write or draw your solution here
            </div>
            <p className="text-xs sm:text-sm text-[#F5F1E6]/70 max-w-md font-sans">
              Use your mouse, stylus, or touch screen to write answers, work through equations, or sketch diagrams.
            </p>
          </div>
        )}

        {/* Clear Confirm Dialog */}
        {showClearConfirm && (
          <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#1C2B24] border border-[#F5F1E6]/15 p-6 rounded-2xl max-w-sm w-full shadow-2xl text-center">
              <h3 className="font-hand text-2xl text-[#E8C468] mb-2">Clear the slate?</h3>
              <p className="text-xs text-[#F5F1E6]/70 mb-5 leading-relaxed">
                This will erase all handwritten strokes on the chalkboard. This action cannot be undone.
              </p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-[#F5F1E6]/80 hover:bg-[#2A473B] transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleClear}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#E2725B] text-white hover:bg-[#eb7f69] transition-colors shadow-lg shadow-[#E2725B]/20"
                >
                  Erase Everything
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
