export interface StrokePoint {
  x: number;
  y: number;
  pressure?: number;
}

export interface Stroke {
  id: string;
  type: 'pen' | 'erase';
  points: StrokePoint[];
  color: string;
  width: number;
}

export interface MistakeItem {
  text_snippet: string;
  issue: string;
  correction: string;
  explanation?: string;
}

export interface FeedbackResult {
  overall_score: number;
  praise: string;
  mistakes: MistakeItem[];
  tips?: string[];
  transcribed_text?: string;
  topic?: string;
  question?: string;
}

export interface FeedbackHistoryItem {
  id: string;
  topic: string;
  question?: string;
  score: number;
  date: number;
  mistakesCount: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
}

export interface ChalkColorOption {
  id: string;
  name: string;
  hex: string;
  label: string;
}

export type BoardThemeId = 'forest' | 'slate' | 'black' | 'navy' | 'vintage';

export interface BoardThemeOption {
  id: BoardThemeId;
  name: string;
  description: string;
  preview: string;
  gradient: [string, string, string];
  dustAlpha: number;
  ruledLineColor: string;
  gridLineColor: string;
  gridMajorColor: string;
  marginColor: string;
  appBackground: string;
  panelBackground: string;
  accentColor: string;
}

export type DrawingImageStyle = 
  | 'realistic' 
  | 'illustration' 
  | 'watercolor' 
  | '3d-render' 
  | 'anime' 
  | 'chalk-masterpiece';

export interface GeneratedDrawingImage {
  id: string;
  imageUrl: string;
  originalCanvasSnapshot?: string;
  subject: string;
  detailedDescription: string;
  imagePrompt: string;
  style: DrawingImageStyle;
  educationalFact?: string;
  category?: string;
  timestamp: number;
}

export interface AutoDrawStroke {
  color: string;
  width: number;
  points: { x: number; y: number }[];
  label?: string;
  type?: 'pen' | 'erase';
}

export interface AutoDrawResult {
  title: string;
  description: string;
  category: string;
  strokes: AutoDrawStroke[];
  educationalInsight?: string;
  stepNotes?: string[];
}

